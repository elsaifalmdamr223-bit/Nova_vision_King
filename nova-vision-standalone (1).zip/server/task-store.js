import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

export function createTaskStore(dataDirectory) {
  const filePath = path.join(dataDirectory, 'tasks.json');

  async function readTasks() {
    try {
      const raw = await readFile(filePath, 'utf8');
      const value = JSON.parse(raw);
      if (!Array.isArray(value)) {
        throw new Error('Stored task data must be an array.');
      }
      return value;
    } catch (error) {
      if (error?.code === 'ENOENT') return [];
      throw error;
    }
  }

  async function writeTasks(tasks) {
    await mkdir(dataDirectory, { recursive: true, mode: 0o700 });
    const temporaryPath = path.join(dataDirectory, `.tasks-${randomUUID()}.tmp`);
    await writeFile(temporaryPath, `${JSON.stringify(tasks, null, 2)}\n`, {
      encoding: 'utf8',
      flag: 'wx',
      mode: 0o600,
    });
    await rename(temporaryPath, filePath);
  }

  return { readTasks, writeTasks, filePath };
}
