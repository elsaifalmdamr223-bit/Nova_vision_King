import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { createNovaServer } from './app.js';
import { createPasswordHash } from './auth.js';

async function startTestServer(options) {
  const server = createNovaServer({ staticDirectory: null, ...options });
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  const address = server.address();
  return {
    server,
    origin: `http://127.0.0.1:${address.port}`,
    async close() {
      server.closeAllConnections();
      await new Promise((resolve, reject) => {
        server.close((error) => error ? reject(error) : resolve());
      });
    },
  };
}

test('health reports demo configuration and task routes fail closed without owner auth', async () => {
  const dataDirectory = await mkdtemp(path.join(os.tmpdir(), 'nova-vision-unconfigured-'));
  const app = await startTestServer({ env: {}, dataDirectory });
  try {
    const health = await fetch(`${app.origin}/api/health`).then((response) => response.json());
    assert.equal(health.status, 'ok');
    assert.equal(health.authConfigured, false);
    assert.equal(health.database, 'not-configured');
    assert.equal(health.agents, 'not-connected');

    const tasksResponse = await fetch(`${app.origin}/api/tasks`);
    assert.equal(tasksResponse.status, 503);
    assert.equal((await tasksResponse.json()).error, 'OWNER_AUTH_NOT_CONFIGURED');
  } finally {
    await app.close();
    await rm(dataDirectory, { recursive: true, force: true });
  }
});

test('configured owner can sign in, persist tasks, update status, and sign out', async () => {
  const dataDirectory = await mkdtemp(path.join(os.tmpdir(), 'nova-vision-authenticated-'));
  const password = `${randomBytes(32).toString('base64url')}Aa1!`;
  const passwordHash = await createPasswordHash(password);
  const env = {
    NODE_ENV: 'test',
    OWNER_EMAIL: 'owner@example.test',
    OWNER_PASSWORD_HASH: passwordHash,
    SESSION_SECRET: randomBytes(48).toString('hex'),
  };
  const wrongPassword = `${randomBytes(32).toString('base64url')}Bb2!`;
  const app = await startTestServer({ env, dataDirectory });

  try {
    const wrongCredentials = await fetch(`${app.origin}/api/auth/sign-in`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: env.OWNER_EMAIL, password: wrongPassword }),
    });
    assert.equal(wrongCredentials.status, 401);

    const signIn = await fetch(`${app.origin}/api/auth/sign-in`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: env.OWNER_EMAIL, password }),
    });
    assert.equal(signIn.status, 200);
    const cookie = signIn.headers.get('set-cookie')?.split(';')[0];
    assert.ok(cookie);
    assert.match(signIn.headers.get('set-cookie'), /HttpOnly/);
    assert.match(signIn.headers.get('set-cookie'), /SameSite=Strict/);

    const session = await fetch(`${app.origin}/api/auth/session`, {
      headers: { Cookie: cookie },
    }).then((response) => response.json());
    assert.equal(session.authenticated, true);
    assert.equal(session.owner.email, env.OWNER_EMAIL);

    const created = await fetch(`${app.origin}/api/tasks`, {
      method: 'POST',
      headers: { Cookie: cookie, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Test saved task',
        project: 'Test',
        priority: 'high',
        due: '2026-10-30',
      }),
    });
    assert.equal(created.status, 201);
    const { task } = await created.json();
    assert.equal(task.title, 'Test saved task');
    assert.equal(task.owner, env.OWNER_EMAIL);

    const changed = await fetch(`${app.origin}/api/tasks/${encodeURIComponent(task.id)}`, {
      method: 'PATCH',
      headers: { Cookie: cookie, 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'done' }),
    });
    assert.equal(changed.status, 200);
    assert.equal((await changed.json()).task.status, 'done');

    const summary = await fetch(`${app.origin}/api/reports/summary`, {
      headers: { Cookie: cookie },
    }).then((response) => response.json());
    assert.deepEqual(summary, {
      totalTasks: 1,
      completedTasks: 1,
      openTasks: 0,
      source: 'saved-tasks',
    });

    const storedTasks = JSON.parse(await readFile(path.join(dataDirectory, 'tasks.json'), 'utf8'));
    assert.equal(storedTasks.length, 1);

    const signOut = await fetch(`${app.origin}/api/auth/sign-out`, {
      method: 'POST',
      headers: { Cookie: cookie },
    });
    assert.equal(signOut.status, 200);
    assert.match(signOut.headers.get('set-cookie'), /Max-Age=0/);

    const deniedAfterSignOut = await fetch(`${app.origin}/api/tasks`, {
      headers: { Cookie: cookie },
    });
    assert.equal(deniedAfterSignOut.status, 401);
  } finally {
    await app.close();
    await rm(dataDirectory, { recursive: true, force: true });
  }
});

test('task API validates input and rejects invalid session tokens', async () => {
  const dataDirectory = await mkdtemp(path.join(os.tmpdir(), 'nova-vision-validation-'));
  const password = `${randomBytes(32).toString('base64url')}Aa1!`;
  const passwordHash = await createPasswordHash(password);
  const env = {
    NODE_ENV: 'test',
    OWNER_EMAIL: 'owner@example.test',
    OWNER_PASSWORD_HASH: passwordHash,
    SESSION_SECRET: randomBytes(48).toString('hex'),
  };
  const app = await startTestServer({ env, dataDirectory });

  try {
    const denied = await fetch(`${app.origin}/api/tasks`, {
      headers: { Cookie: 'nova_owner_session=invalid.signature' },
    });
    assert.equal(denied.status, 401);

    const signIn = await fetch(`${app.origin}/api/auth/sign-in`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: env.OWNER_EMAIL, password }),
    });
    const cookie = signIn.headers.get('set-cookie')?.split(';')[0];
    assert.ok(cookie);

    const invalidTask = await fetch(`${app.origin}/api/tasks`, {
      method: 'POST',
      headers: { Cookie: cookie, 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: '' }),
    });
    assert.equal(invalidTask.status, 400);
  } finally {
    await app.close();
    await rm(dataDirectory, { recursive: true, force: true });
  }
});
