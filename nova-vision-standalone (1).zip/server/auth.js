import {
  createHmac,
  randomUUID,
  randomBytes,
  scrypt as scryptCallback,
  timingSafeEqual,
} from 'node:crypto';
import { promisify } from 'node:util';

const scrypt = promisify(scryptCallback);
export const OWNER_COOKIE_NAME = 'nova_owner_session';
export const SESSION_TTL_SECONDS = 60 * 60 * 8;

export function isScryptHash(value) {
  return typeof value === 'string' && /^scrypt\$[a-f0-9]{32}\$[a-f0-9]{128}$/i.test(value);
}

export function getOwnerAuthConfig(env = process.env) {
  const email = String(env.OWNER_EMAIL || '').trim().toLowerCase();
  const passwordHash = String(env.OWNER_PASSWORD_HASH || '');
  const sessionSecret = String(env.SESSION_SECRET || '');
  const missing = [];

  if (!email) missing.push('OWNER_EMAIL');
  if (!isScryptHash(passwordHash)) missing.push('OWNER_PASSWORD_HASH');
  if (sessionSecret.length < 32) missing.push('SESSION_SECRET');

  return {
    configured: missing.length === 0,
    email,
    passwordHash,
    sessionSecret,
    missing,
  };
}

export async function createPasswordHash(password, salt = randomBytes(16)) {
  const derived = await scrypt(password, salt, 64);
  return `scrypt$${salt.toString('hex')}$${Buffer.from(derived).toString('hex')}`;
}

export async function verifyPassword(password, storedHash) {
  if (!isScryptHash(storedHash) || typeof password !== 'string') return false;
  const [, saltHex, expectedHex] = storedHash.split('$');
  const expected = Buffer.from(expectedHex, 'hex');
  const actual = Buffer.from(await scrypt(password, Buffer.from(saltHex, 'hex'), expected.length));
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

function constantTimeStringEqual(left, right) {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer);
}

function sign(value, secret) {
  return createHmac('sha256', secret).update(value).digest('base64url');
}

export function createSessionToken(email, secret, now = Date.now()) {
  const payload = Buffer.from(JSON.stringify({
    email,
    sessionId: randomUUID(),
    exp: Math.floor(now / 1000) + SESSION_TTL_SECONDS,
  })).toString('base64url');
  return `${payload}.${sign(payload, secret)}`;
}

export function verifySessionToken(token, secret, now = Date.now()) {
  if (!token || !secret) return null;
  const separator = token.lastIndexOf('.');
  if (separator <= 0) return null;

  const payload = token.slice(0, separator);
  const suppliedSignature = token.slice(separator + 1);
  const expectedSignature = sign(payload, secret);
  if (!constantTimeStringEqual(suppliedSignature, expectedSignature)) return null;

  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (typeof data.email !== 'string' || typeof data.sessionId !== 'string' || !Number.isFinite(data.exp)) return null;
    if (data.exp <= Math.floor(now / 1000)) return null;
    return { email: data.email, sessionId: data.sessionId, expiresAt: data.exp };
  } catch {
    return null;
  }
}

export function readCookie(request, name) {
  const header = request.headers.cookie;
  if (!header) return '';
  for (const part of header.split(';')) {
    const separator = part.indexOf('=');
    if (separator < 0) continue;
    if (part.slice(0, separator).trim() === name) {
      try {
        return decodeURIComponent(part.slice(separator + 1).trim());
      } catch {
        return '';
      }
    }
  }
  return '';
}

export async function verifyOwnerCredentials(email, password, config) {
  if (!config.configured) return false;
  const normalizedEmail = String(email || '').trim().toLowerCase();
  if (!constantTimeStringEqual(normalizedEmail, config.email)) return false;
  return verifyPassword(password, config.passwordHash);
}

export function cookieHeader(token, env = process.env) {
  const secure = env.NODE_ENV === 'production' && env.COOKIE_SECURE !== 'false';
  return [
    `${OWNER_COOKIE_NAME}=${encodeURIComponent(token)}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Strict',
    `Max-Age=${SESSION_TTL_SECONDS}`,
    ...(secure ? ['Secure'] : []),
  ].join('; ');
}

export function clearCookieHeader(env = process.env) {
  const secure = env.NODE_ENV === 'production' && env.COOKIE_SECURE !== 'false';
  return [
    `${OWNER_COOKIE_NAME}=`,
    'Path=/',
    'HttpOnly',
    'SameSite=Strict',
    'Max-Age=0',
    ...(secure ? ['Secure'] : []),
  ].join('; ');
}
