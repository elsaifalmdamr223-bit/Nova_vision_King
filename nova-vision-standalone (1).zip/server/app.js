import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { access, stat } from 'node:fs/promises';
import path from 'node:path';
import {
  OWNER_COOKIE_NAME,
  clearCookieHeader,
  cookieHeader,
  createSessionToken,
  getOwnerAuthConfig,
  readCookie,
  verifyOwnerCredentials,
  verifySessionToken,
} from './auth.js';
import { createTaskStore } from './task-store.js';

const MAX_BODY_BYTES = 64 * 1024;
const PRIORITY_LABELS = {
  high: 'عالية',
  medium: 'متوسطة',
  low: 'منخفضة',
};
const VALID_STATUSES = new Set(['queued', 'in_progress', 'done']);
const MIME_TYPES = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.ico': 'image/x-icon',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.txt': 'text/plain; charset=utf-8',
  '.webp': 'image/webp',
  '.woff2': 'font/woff2',
};

function sendJson(response, status, body, headers = {}) {
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
  response.end(JSON.stringify(body));
}

async function readJsonBody(request) {
  const chunks = [];
  let totalBytes = 0;
  for await (const chunk of request) {
    totalBytes += chunk.length;
    if (totalBytes > MAX_BODY_BYTES) {
      const error = new Error('Request body is too large.');
      error.statusCode = 413;
      throw error;
    }
    chunks.push(chunk);
  }
  if (totalBytes === 0) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    const error = new Error('Request body must be valid JSON.');
    error.statusCode = 400;
    throw error;
  }
}

function requestSession(request, authConfig, sessions) {
  if (!authConfig.configured) return null;
  const token = readCookie(request, OWNER_COOKIE_NAME);
  const session = verifySessionToken(token, authConfig.sessionSecret);
  if (!session || session.email !== authConfig.email) return null;
  const activeSession = sessions.get(session.sessionId);
  if (!activeSession || activeSession.expiresAt <= Math.floor(Date.now() / 1000)) {
    sessions.delete(session.sessionId);
    return null;
  }
  return activeSession.email === session.email ? session : null;
}

function authFailure(response, authConfig, session) {
  if (!authConfig.configured) {
    sendJson(response, 503, {
      error: 'OWNER_AUTH_NOT_CONFIGURED',
      message: 'Owner authentication is not configured. Protected data remains unavailable.',
    });
    return true;
  }
  if (!session) {
    sendJson(response, 401, {
      error: 'OWNER_AUTH_REQUIRED',
      message: 'Owner sign-in is required for this operation.',
    });
    return true;
  }
  return false;
}

function initialsFromEmail(email) {
  const localPart = email.split('@')[0] || 'NV';
  return Array.from(localPart).slice(0, 2).join('').toUpperCase();
}

function validateTaskInput(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return 'Task data must be an object.';
  }
  if (typeof body.title !== 'string' || !body.title.trim() || body.title.trim().length > 160) {
    return 'Task title is required and must be 160 characters or fewer.';
  }
  for (const field of ['project', 'due']) {
    if (body[field] !== undefined && (typeof body[field] !== 'string' || body[field].length > 120)) {
      return `${field} must be a string of 120 characters or fewer.`;
    }
  }
  if (body.priority !== undefined && !Object.hasOwn(PRIORITY_LABELS, body.priority)) {
    return 'Priority must be high, medium, or low.';
  }
  return '';
}

function normalizeTask(body, owner) {
  const priority = body.priority || 'medium';
  return {
    id: `task-${randomUUID()}`,
    title: body.title.trim(),
    project: (body.project || '').trim(),
    owner,
    ownerInitials: initialsFromEmail(owner),
    ownerTone: 'teal',
    priority,
    priorityLabel: PRIORITY_LABELS[priority],
    due: (body.due || '').trim(),
    status: 'queued',
    createdAt: new Date().toISOString(),
  };
}

async function serveStatic(request, response, pathname, staticDirectory) {
  if (!staticDirectory) {
    sendJson(response, 404, { error: 'NOT_FOUND' });
    return;
  }
  let requestedPath;
  try {
    requestedPath = decodeURIComponent(pathname);
  } catch {
    sendJson(response, 400, { error: 'INVALID_PATH' });
    return;
  }

  const safeRelativePath = requestedPath.replace(/^\/+/, '');
  let filePath = path.resolve(staticDirectory, safeRelativePath || 'index.html');
  const rootPath = path.resolve(staticDirectory);
  if (filePath !== rootPath && !filePath.startsWith(`${rootPath}${path.sep}`)) {
    sendJson(response, 403, { error: 'FORBIDDEN' });
    return;
  }

  try {
    await access(filePath);
    const info = await stat(filePath);
    if (info.isDirectory()) filePath = path.join(filePath, 'index.html');
    await access(filePath);
  } catch {
    filePath = path.join(rootPath, 'index.html');
    try {
      await access(filePath);
    } catch {
      sendJson(response, 503, {
        error: 'BUILD_NOT_FOUND',
        message: 'Build the frontend with npm run build before starting the production server.',
      });
      return;
    }
  }

  response.writeHead(200, {
    'Content-Type': MIME_TYPES[path.extname(filePath)] || 'application/octet-stream',
    'Cache-Control': filePath.endsWith('index.html') ? 'no-cache' : 'public, max-age=3600',
    'X-Content-Type-Options': 'nosniff',
  });
  if (request.method === 'HEAD') {
    response.end();
    return;
  }
  createReadStream(filePath).pipe(response);
}

export function createNovaServer({
  env = process.env,
  dataDirectory = process.env.NOVA_DATA_DIR || path.join(process.cwd(), 'data'),
  staticDirectory = path.join(process.cwd(), 'dist', 'public'),
} = {}) {
  const authConfig = getOwnerAuthConfig(env);
  const taskStore = createTaskStore(dataDirectory);
  const attempts = new Map();
  const sessions = new Map();

  return createServer(async (request, response) => {
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Referrer-Policy', 'same-origin');
    response.setHeader('X-Frame-Options', 'DENY');

    let url;
    try {
      url = new URL(request.url || '/', 'http://localhost');
    } catch {
      sendJson(response, 400, { error: 'INVALID_URL' });
      return;
    }
    const pathname = url.pathname;

    if (!pathname.startsWith('/api/')) {
      await serveStatic(request, response, pathname, staticDirectory);
      return;
    }

    try {
      if (pathname === '/api/health' && request.method === 'GET') {
        sendJson(response, 200, {
          status: 'ok',
          authConfigured: authConfig.configured,
          authMissingSettings: authConfig.missing,
          taskStorage: 'local-json-file',
          database: 'not-configured',
          agents: 'not-connected',
        });
        return;
      }

      if (pathname === '/api/auth/session' && request.method === 'GET') {
        const session = requestSession(request, authConfig, sessions);
        sendJson(response, 200, {
          configured: authConfig.configured,
          authenticated: Boolean(session),
          owner: session ? { email: session.email } : null,
        });
        return;
      }

      if (pathname === '/api/auth/sign-in' && request.method === 'POST') {
        if (!authConfig.configured) {
          sendJson(response, 503, { error: 'OWNER_AUTH_NOT_CONFIGURED' });
          return;
        }
        const ip = request.socket.remoteAddress || 'unknown';
        const now = Date.now();
        const recentAttempts = (attempts.get(ip) || []).filter((timestamp) => now - timestamp < 15 * 60_000);
        if (recentAttempts.length >= 10) {
          attempts.set(ip, recentAttempts);
          sendJson(response, 429, { error: 'SIGN_IN_RATE_LIMITED' });
          return;
        }
        recentAttempts.push(now);
        attempts.set(ip, recentAttempts);

        const body = await readJsonBody(request);
        const password = typeof body.password === 'string' ? body.password : '';
        const valid = password.length >= 14
          && password.length <= 128
          && await verifyOwnerCredentials(body.email, password, authConfig);
        if (!valid) {
          sendJson(response, 401, { error: 'INVALID_CREDENTIALS' });
          return;
        }
        attempts.delete(ip);
        const token = createSessionToken(authConfig.email, authConfig.sessionSecret);
        const session = verifySessionToken(token, authConfig.sessionSecret);
        for (const [sessionId, existingSession] of sessions) {
          if (existingSession.expiresAt <= Math.floor(Date.now() / 1000)) sessions.delete(sessionId);
        }
        sessions.set(session.sessionId, {
          email: authConfig.email,
          expiresAt: session.expiresAt,
        });
        sendJson(response, 200, {
          configured: true,
          authenticated: true,
          owner: { email: authConfig.email },
        }, { 'Set-Cookie': cookieHeader(token, env) });
        return;
      }

      if (pathname === '/api/auth/sign-out' && request.method === 'POST') {
        const token = readCookie(request, OWNER_COOKIE_NAME);
        const session = verifySessionToken(token, authConfig.sessionSecret);
        if (session) sessions.delete(session.sessionId);
        sendJson(response, 200, { authenticated: false }, {
          'Set-Cookie': clearCookieHeader(env),
        });
        return;
      }

      if (pathname === '/api/tasks' || pathname.startsWith('/api/tasks/')) {
        const session = requestSession(request, authConfig, sessions);
        if (authFailure(response, authConfig, session)) return;

        if (pathname === '/api/tasks' && request.method === 'GET') {
          sendJson(response, 200, { tasks: await taskStore.readTasks() });
          return;
        }

        if (pathname === '/api/tasks' && request.method === 'POST') {
          const body = await readJsonBody(request);
          const validationMessage = validateTaskInput(body);
          if (validationMessage) {
            sendJson(response, 400, { error: 'INVALID_TASK', message: validationMessage });
            return;
          }
          const tasks = await taskStore.readTasks();
          const task = normalizeTask(body, session.email);
          tasks.push(task);
          await taskStore.writeTasks(tasks);
          sendJson(response, 201, { task });
          return;
        }

        const taskMatch = pathname.match(/^\/api\/tasks\/([^/]+)$/);
        if (taskMatch && request.method === 'PATCH') {
          const body = await readJsonBody(request);
          if (!VALID_STATUSES.has(body.status)) {
            sendJson(response, 400, { error: 'INVALID_STATUS' });
            return;
          }
          const taskId = decodeURIComponent(taskMatch[1]);
          const tasks = await taskStore.readTasks();
          const taskIndex = tasks.findIndex((task) => task.id === taskId);
          if (taskIndex < 0) {
            sendJson(response, 404, { error: 'TASK_NOT_FOUND' });
            return;
          }
          tasks[taskIndex] = { ...tasks[taskIndex], status: body.status };
          await taskStore.writeTasks(tasks);
          sendJson(response, 200, { task: tasks[taskIndex] });
          return;
        }

        sendJson(response, 405, { error: 'METHOD_NOT_ALLOWED' }, { Allow: 'GET, POST, PATCH' });
        return;
      }

      if (pathname === '/api/reports/summary' && request.method === 'GET') {
        const session = requestSession(request, authConfig, sessions);
        if (authFailure(response, authConfig, session)) return;
        const tasks = await taskStore.readTasks();
        sendJson(response, 200, {
          totalTasks: tasks.length,
          completedTasks: tasks.filter((task) => task.status === 'done').length,
          openTasks: tasks.filter((task) => task.status !== 'done').length,
          source: 'saved-tasks',
        });
        return;
      }

      sendJson(response, 404, { error: 'API_ROUTE_NOT_FOUND' });
    } catch (error) {
      if (error?.statusCode) {
        sendJson(response, error.statusCode, { error: error.statusCode === 413 ? 'BODY_TOO_LARGE' : 'INVALID_REQUEST' });
        return;
      }
      console.error('Nova Vision API request failed:', error?.message || 'unknown error');
      sendJson(response, 500, { error: 'INTERNAL_SERVER_ERROR' });
    }
  });
}
