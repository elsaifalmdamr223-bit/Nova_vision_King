import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createNovaServer } from './app.js';
import { getOwnerAuthConfig } from './auth.js';

const projectRoot = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const production = process.argv.includes('--production');
const runtimeEnv = production ? { ...process.env, NODE_ENV: 'production' } : process.env;
const port = Number(production
  ? (process.env.PORT || 5000)
  : (process.env.API_PORT || 3001));

if (!Number.isInteger(port) || port <= 0 || port > 65535) {
  console.error('API_PORT or PORT must be a valid TCP port.');
  process.exit(1);
}

const server = createNovaServer({
  env: runtimeEnv,
  dataDirectory: runtimeEnv.NOVA_DATA_DIR || path.join(projectRoot, 'data'),
  staticDirectory: production ? path.join(projectRoot, 'dist', 'public') : null,
});

server.listen(port, '0.0.0.0', () => {
  console.log(`Nova Vision server listening on port ${port}`);
  console.log('Owner authentication:', getOwnerAuthConfig(runtimeEnv).configured
    ? 'configured'
    : 'not configured; demo mode only');
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    server.close(() => process.exit(0));
  });
}
