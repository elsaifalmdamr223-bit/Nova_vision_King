import { randomBytes, scrypt as scryptCallback } from 'node:crypto';
import { promisify } from 'node:util';

const scrypt = promisify(scryptCallback);

function readHiddenPassword(prompt) {
  return new Promise((resolve, reject) => {
    if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== 'function') {
      reject(new Error('Run this command in an interactive terminal.'));
      return;
    }

    process.stdout.write(prompt);
    process.stdin.setRawMode(true);
    process.stdin.resume();
    let value = '';

    const finish = (error) => {
      process.stdin.setRawMode(false);
      process.stdin.pause();
      process.stdin.removeListener('data', onData);
      process.stdout.write('\n');
      if (error) reject(error);
      else resolve(value);
    };

    const onData = (chunk) => {
      for (const character of chunk.toString('utf8')) {
        if (character === '\u0003') {
          finish(new Error('Cancelled.'));
          return;
        }
        if (character === '\r' || character === '\n') {
          finish();
          return;
        }
        if (character === '\u007f' || character === '\b') {
          value = value.slice(0, -1);
          continue;
        }
        if (character >= ' ') value += character;
      }
    };

    process.stdin.on('data', onData);
  });
}

try {
  const password = await readHiddenPassword('Enter the owner password (hidden): ');
  if (password.length < 14) {
    throw new Error('Use a password with at least 14 characters.');
  }
  const salt = randomBytes(16);
  const digest = await scrypt(password, salt, 64);
  console.log(`OWNER_PASSWORD_HASH=scrypt$${salt.toString('hex')}$${Buffer.from(digest).toString('hex')}`);
  console.log('Copy this hash directly into Replit Secrets; do not send it in chat or commit it.');
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
