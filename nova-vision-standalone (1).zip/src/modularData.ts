export type SurfaceState = 'Designed' | 'Simulated' | 'Live' | 'Blocked';
export type FailoverTier = 'Primary' | 'Standby' | 'Cold Backup';

export type AgentDefinition = {
  id: string;
  name: string;
  role: string;
  mission: string;
  inputs: string;
  outputs: string;
  tools: string[];
  dataAccess: string;
  allowed: string;
  denied: string;
  reviewer: string;
  escalation: string;
  qualityGate: string;
  state: SurfaceState;
  prompt: string;
  taskLog: {
    lastTask: string;
    lastResult: string;
    lastError: string;
  };
  failover: {
    tier: FailoverTier;
    standby: string;
    coldBackup: string;
    checkpoint: string;
    knownGoodVersion: string;
  };
  latestTest: string;
  currentVersion: string;
};

type AgentSeed = {
  name: string;
  role: string;
  mission: string;
  inputs: string;
  outputs: string;
  tools: string[];
  dataAccess: string;
  allowed: string;
  denied: string;
  qualityGate: string;
  state?: SurfaceState;
  tier?: FailoverTier;
};

export type DomainDefinition = {
  id: string;
  name: string;
  english: string;
  manager: string;
  qa: string;
  agents: AgentDefinition[];
  memory: string;
  queue: string;
  tools: string[];
  boundary: string;
  interface: string;
  state: SurfaceState;
  tone: 'teal' | 'violet' | 'amber' | 'blue' | 'rose';
  workspace: {
    accountName: string;
    knowledgeBase: string;
    filesData: string;
    projectsClients: string;
    auditLog: string;
    approvalQueue: string;
    dashboard: string;
    permissions: string;
  };
};

const stateLabel: Record<SurfaceState, string> = {
  Designed: 'تصميم محدد',
  Simulated: 'محاكاة محلية',
  Live: 'اتصال حي',
  Blocked: 'محجوب حتى الموافقة',
};

function makeAgent(
  domainId: string,
  manager: string,
  qa: string,
  index: number,
  seed: AgentSeed,
): AgentDefinition {
  const id = `${domainId}-${String(index + 1).padStart(2, '0')}`;
  const tier = seed.tier ?? (index % 3 === 0 ? 'Primary' : index % 3 === 1 ? 'Standby' : 'Cold Backup');
  const state = seed.state ?? 'Designed';
  const steps = `استخرج المدخلات، تحقق من النطاق والمصدر، نفّذ التحليل المتخصص في ${seed.role}، أنشئ مخرجاً قابلاً للمراجعة، ثم سجّل الأدلة والافتراضات.`;
  return {
    id,
    name: seed.name,
    role: seed.role,
    mission: seed.mission,
    inputs: seed.inputs,
    outputs: seed.outputs,
    tools: seed.tools,
    dataAccess: seed.dataAccess,
    allowed: seed.allowed,
    denied: seed.denied,
    reviewer: qa,
    escalation: manager,
    qualityGate: seed.qualityGate,
    state,
    prompt: [
      `الهدف: ${seed.mission}.`,
      `نطاق العمل: أنت وكيل متخصص في ${seed.role} داخل مجال ${domainId}، ولا تعمل خارج هذا النطاق.`,
      `المدخلات: ${seed.inputs}.`,
      `خطوات التحليل والإنتاج: ${steps}`,
      `المخرجات: ${seed.outputs}.`,
      `معيار الجودة: ${seed.qualityGate}.`,
      `ارفض أو أَحِل إلى ${manager} أي طلب خارج الصلاحيات، أو يطلب بيانات مجال آخر، أو تنفيذاً مالياً/قانونياً/خارجياً غير معتمد.`,
    ].join('\n'),
    taskLog: {
      lastTask: `مهمة Demo: ${seed.mission}`,
      lastResult: `مخرج ${stateLabel[state]} بانتظار مراجعة ${qa}`,
      lastError: 'لا يوجد خطأ مسجل في بيئة العرض',
    },
    failover: {
      tier,
      standby: `${seed.name} / Standby`,
      coldBackup: `${seed.name} / Cold Backup`,
      checkpoint: `checkpoint-${id}-known-good`,
      knownGoodVersion: 'v0.1-designed',
    },
    latestTest: 'Sandbox boundary check · Regression pending',
    currentVersion: 'v0.1-designed',
  };
}

function createDomain(
  config: Omit<DomainDefinition, 'agents' | 'workspace'> & {
    workspace?: Partial<DomainDefinition['workspace']>;
    agentSeeds: AgentSeed[];
  },
): DomainDefinition {
  const agents = config.agentSeeds.map((seed, index) => makeAgent(config.id, config.manager, config.qa, index, seed));
  return {
    ...config,
    agents,
    workspace: {
      accountName: `Nova Workspace / ${config.name}`,
      knowledgeBase: config.memory,
      filesData: 'حاوية ملفات وبيانات منفصلة منطقياً، بلا وصول عام',
      projectsClients: 'مشاريع وعملاء المجال فقط',
      auditLog: 'سجل تدقيق مجالّي: طلب، مخرج، مراجعة، خطأ',
      approvalQueue: 'طلبات الحساسية والتسليم الخارجي',
      dashboard: 'لوحة مؤشرات وتقارير خاصة بالمجال',
      permissions: 'Zero Trust · أقل صلاحية · صلاحيات مستقلة',
      ...config.workspace,
    },
  };
}

const common = {
  allowed: 'قراءة المدخلات المصرح بها، إنتاج مسودة، وتسجيل الأدلة',
  denied: 'الوصول العام، كشف الأسرار، التنفيذ الخارجي، وتجاوز المدير أو QA',
};

export const domainDefinitions: DomainDefinition[] = [
  createDomain({
    id: 'market',
    name: 'أبحاث السوق والمنافسين',
    english: 'Market & Competitor Research',
    manager: 'مدير أبحاث السوق',
    qa: 'QA أبحاث السوق',
    memory: 'إشارات السوق والمصادر',
    queue: 'أبحاث وفرضيات',
    tools: ['مصنف الإشارات', 'مقارن المصادر'],
    boundary: 'لا يصل إلى ملفات العملاء أو التسعير الداخلي',
    interface: 'طلب رسمي إلى الفرص والتسويق',
    state: 'Simulated',
    tone: 'teal',
    agentSeeds: [
      { name: 'راصد اتجاهات السوق', role: 'اكتشاف الاتجاهات', mission: 'التقاط تغيرات السوق القابلة للتحقق', inputs: 'مصادر سوق مصرح بها وفرضيات بحث', outputs: 'موجز اتجاهات مع مصادر وثقة', tools: ['مصنف الإشارات'], dataAccess: 'مصادر السوق العامة المفهرسة', ...common, qualityGate: 'مصدران مستقلان أو وسم الإشارة كغير مؤكدة' },
      { name: 'محلل المنافسين', role: 'تحليل المنافسة', mission: 'بناء مقارنة موضوعية للمنافسين', inputs: 'ملفات منافسين ومصادر منشورة', outputs: 'مصفوفة مقارنة ونقاط تحقق', tools: ['مقارن المصادر'], dataAccess: 'ملفات المنافسين العامة داخل المجال', ...common, qualityGate: 'كل ادعاء مرتبط بمصدر وتاريخ' },
      { name: 'موثق المصادر', role: 'توثيق الأدلة', mission: 'تثبيت المصدر وسياقه قبل استخدامه', inputs: 'روابط ومقتطفات وبيانات مصدر', outputs: 'سجل مصدر وبصمة محتوى', tools: ['مدقق المصدر'], dataAccess: 'سجل المصادر فقط', ...common, qualityGate: 'الرابط والسياق والبصمة مكتملة' },
      { name: 'باحث شرائح العملاء', role: 'تقسيم السوق', mission: 'اقتراح شرائح سوق قابلة للاختبار', inputs: 'إشارات السوق وبيانات مجهّلة', outputs: 'شرائح وفرضيات احتياج', tools: ['مصفوفة الشرائح'], dataAccess: 'بيانات سوق مجهّلة لا بيانات هوية', ...common, qualityGate: 'كل شريحة لها دليل وفرضية اختبار' },
      { name: 'مقدر حجم الفرصة', role: 'تقدير أولي للسوق', mission: 'حساب نطاقات حجم الفرصة دون توصية استثمارية', inputs: 'مؤشرات منشورة وافتراضات موثقة', outputs: 'نطاق TAM/SAM/SOM تجريبي', tools: ['حاسبة النطاق'], dataAccess: 'مؤشرات عامة وافتراضات البحث', ...common, qualityGate: 'عرض النطاق والافتراضات والحساسية' },
      { name: 'مراجع أبحاث السوق', role: 'مراجعة بحثية', mission: 'كشف الفجوات والتحيز قبل تسليم البحث', inputs: 'مخرجات وكلاء البحث وسجل الأدلة', outputs: 'قرار QA وملاحظات تصحيح', tools: ['قائمة بوابة البحث'], dataAccess: 'مخرجات المجال وسجل التدقيق', ...common, qualityGate: 'لا تسليم قبل اكتمال الأدلة والحدود', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'automation',
    name: 'أتمتة الأعمال بالذكاء الاصطناعي',
    english: 'AI Business Automation',
    manager: 'مدير الأتمتة',
    qa: 'QA أتمتة الأعمال',
    memory: 'خرائط العمليات والقواعد',
    queue: 'طلبات أتمتة',
    tools: ['مخطط سير العمل', 'محاكي التشغيل'],
    boundary: 'أقل صلاحية على بيانات التشغيل',
    interface: 'عقود مهام مع التطوير والدعم',
    state: 'Designed',
    tone: 'violet',
    agentSeeds: [
      { name: 'محلل العمليات', role: 'اكتشاف العملية', mission: 'تفكيك العملية الحالية إلى خطوات قابلة للأتمتة', inputs: 'وصف العملية وقيودها', outputs: 'خريطة عملية ونقاط قرار', tools: ['مخطط سير العمل'], dataAccess: 'خرائط العمليات المصرح بها', ...common, qualityGate: 'كل خطوة لها مالك ومدخل ومخرج' },
      { name: 'مصمم سير العمل', role: 'تصميم الأتمتة', mission: 'تصميم Workflow آمن قابل للمحاكاة', inputs: 'خريطة عملية ومعايير نجاح', outputs: 'تصميم Workflow وإصداره', tools: ['مخطط سير العمل'], dataAccess: 'مواصفات العملية فقط', ...common, qualityGate: 'مسارات الفشل والحدود موثقة' },
      { name: 'مهندس المحفزات', role: 'هندسة Prompts', mission: 'كتابة أمر داخلي مضبوط لوكيل أو خطوة', inputs: 'هدف الخطوة وأمثلة آمنة', outputs: 'Prompt مع حدود واختبارات', tools: ['Prompt Sandbox'], dataAccess: 'أمثلة منزوعة الحساسية', ...common, qualityGate: 'اختبار رفض النطاق وتسريب الأسرار ناجح' },
      { name: 'محاكي التشغيل', role: 'محاكاة التنفيذ', mission: 'تشغيل السيناريو في Sandbox دون أثر خارجي', inputs: 'Workflow ومدخلات اختبار', outputs: 'سجل محاكاة ونتائج متوقعة', tools: ['محاكي التشغيل'], dataAccess: 'بيانات Sandbox فقط', ...common, qualityGate: 'لا اتصال خارجي ولا كتابة إنتاجية' },
      { name: 'مراقب التكامل', role: 'فحص واجهات التكامل', mission: 'التحقق من عقود الطلبات بين الوحدات', inputs: 'Interface Contract ومخرجات المجال', outputs: 'تقرير توافق ونطاق', tools: ['مدقق العقود'], dataAccess: 'عقود التكامل لا بيانات المجالات', ...common, qualityGate: 'المصدر والسبب والنطاق والمدة موجودة' },
      { name: 'مراجع مخاطر الأتمتة', role: 'تقييم المخاطر', mission: 'تحديد مخاطر الخطأ والتصعيد البشري', inputs: 'تصميم Workflow وسجل المحاكاة', outputs: 'مصفوفة مخاطر وضوابط', tools: ['مصفوفة المخاطر'], dataAccess: 'تصاميم الأتمتة ونتائج الاختبار', ...common, qualityGate: 'كل خطر له ضابط ومالك' },
      { name: 'QA أتمتة الأعمال', role: 'بوابة تسليم الأتمتة', mission: 'قبول الأتمتة أو إعادتها قبل النشر', inputs: 'كل مخرجات ووثائق المجال', outputs: 'قرار QA وإصدار معروف', tools: ['Regression Sandbox'], dataAccess: 'سجل المجال الكامل', ...common, qualityGate: 'Regression وSecurity Review وRollback جاهزة', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'bi',
    name: 'تحليل البيانات وذكاء الأعمال',
    english: 'Data & Business Intelligence',
    manager: 'مدير ذكاء الأعمال',
    qa: 'QA البيانات وBI',
    memory: 'قاموس البيانات ومؤشرات الأداء',
    queue: 'استعلامات وتقارير',
    tools: ['محلل الجداول', 'باني لوحة المؤشرات'],
    boundary: 'بيانات مصنفة ومقيدة حسب العميل',
    interface: 'طلبات بيانات موثقة فقط',
    state: 'Designed',
    tone: 'blue',
    agentSeeds: [
      { name: 'مكتشف مصادر البيانات', role: 'جرد البيانات', mission: 'حصر مصادر البيانات المسموح بها وحدودها', inputs: 'كتالوج المصادر وطلبات البيانات', outputs: 'جرد مصدر وتصنيف', tools: ['محلل الجداول'], dataAccess: 'Metadata المصادر فقط', ...common, qualityGate: 'المالك والتصنيف وحداثة المصدر واضحة' },
      { name: 'محلل البيانات', role: 'تحليل وصفي', mission: 'استخراج أنماط وصفية من بيانات مصرح بها', inputs: 'جداول مصنفة وسؤال تحليلي', outputs: 'نتائج وصفية مع استعلامات', tools: ['محلل الجداول'], dataAccess: 'مساحة بيانات العميل المصرح بها', ...common, qualityGate: 'الاستعلام قابل لإعادة التشغيل والنتيجة قابلة للتتبع' },
      { name: 'باني المؤشرات', role: 'تعريف KPI', mission: 'تحويل أهداف العمل إلى مؤشرات قابلة للقياس', inputs: 'أهداف وتعريفات بيانات', outputs: 'قاموس KPI وصيغ الحساب', tools: ['باني لوحة المؤشرات'], dataAccess: 'قاموس البيانات وبيانات مجهّلة', ...common, qualityGate: 'التعريف والمالك ونافذة القياس مكتملة' },
      { name: 'مراجع جودة البيانات', role: 'Data Quality', mission: 'اختبار الاكتمال والاتساق والتكرار', inputs: 'جداول ونتائج تحليل', outputs: 'تقرير جودة وعيوب', tools: ['فاحص الجودة'], dataAccess: 'عينات بيانات مصرح بها', ...common, qualityGate: 'نتائج الاختبار مع عتبات واضحة' },
      { name: 'مصور لوحة المؤشرات', role: 'تصميم تقارير BI', mission: 'إنشاء لوحة قراءة لا توحي بدقة زائفة', inputs: 'KPI معتمد وبيانات ملخصة', outputs: 'تصميم لوحة وملاحظات قراءة', tools: ['باني لوحة المؤشرات'], dataAccess: 'Aggregates معتمدة فقط', ...common, qualityGate: 'كل رسم له مصدر وتعريف وتاريخ تحديث' },
      { name: 'QA ذكاء الأعمال', role: 'قبول تقارير البيانات', mission: 'مراجعة التقرير قبل تسليمه للعميل', inputs: 'الاستعلام واللوحة وتقرير الجودة', outputs: 'قرار تسليم وملاحظات', tools: ['بوابة BI'], dataAccess: 'مخرجات المجال وسجل التدقيق', ...common, qualityGate: 'اتساق المصدر والحساب والخصوصية', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'software',
    name: 'البرمجة والمواقع والتطبيقات',
    english: 'Software, Websites & Applications',
    manager: 'مدير التطوير',
    qa: 'QA البرمجيات',
    memory: 'مواصفات وإصدارات المشاريع',
    queue: 'تذاكر التطوير',
    tools: ['بيئة التطوير', 'مختبر Regression'],
    boundary: 'كل مشروع وعميل في مساحة معزولة',
    interface: 'عقود تسليم مع التصميم والمبيعات',
    state: 'Simulated',
    tone: 'blue',
    agentSeeds: [
      { name: 'محلل المتطلبات', role: 'تحليل المتطلبات', mission: 'تحويل طلب العميل إلى مواصفات قابلة للاختبار', inputs: 'طلب العميل وقيود المشروع', outputs: 'قصة مستخدم ومعايير قبول', tools: ['محرر المواصفات'], dataAccess: 'ملفات المشروع والطلب فقط', ...common, qualityGate: 'لا غموض في النطاق أو معيار القبول' },
      { name: 'مصمم المعمارية', role: 'هندسة الحلول', mission: 'اقتراح معمارية مناسبة لحجم ومخاطر المشروع', inputs: 'المتطلبات والقيود التقنية', outputs: 'قرار معماري ومخطط مكونات', tools: ['مخطط المعمارية'], dataAccess: 'مواصفات المشروع لا أسرار الإنتاج', ...common, qualityGate: 'البدائل والمخاطر وحدود القرار موثقة' },
      { name: 'مهندس الواجهة', role: 'تطوير Frontend', mission: 'بناء واجهة قابلة للاستخدام وفق المواصفات', inputs: 'تصميم معتمد ومواصفات UI', outputs: 'مكونات واجهة واختباراتها', tools: ['بيئة التطوير'], dataAccess: 'مستودع المشروع المعزول', ...common, qualityGate: 'الحالات الفارغة والخطأ والاستجابة مختبرة' },
      { name: 'مهندس الخدمات', role: 'تطوير Backend', mission: 'تنفيذ خدمات آمنة بعقود واضحة', inputs: 'مواصفات API ونموذج البيانات', outputs: 'مسارات وخدمات موثقة', tools: ['بيئة التطوير'], dataAccess: 'كود المشروع ومخطط API', ...common, qualityGate: 'التحقق من الإدخال والصلاحيات واختبارات العقد' },
      { name: 'مهندس البيانات التطبيقية', role: 'نمذجة بيانات التطبيق', mission: 'تصميم نماذج بيانات تحفظ العزل والتتبع', inputs: 'متطلبات الكيانات وعقود API', outputs: 'مخطط بيانات وترحيلات مقترحة', tools: ['مخطط البيانات'], dataAccess: 'مخطط المشروع دون بيانات إنتاج', ...common, qualityGate: 'الملكية والعزل والفهارس موثقة' },
      { name: 'مهندس التكامل', role: 'ربط الخدمات', mission: 'تنفيذ واجهات التكامل المسجلة فقط', inputs: 'Interface Contract ومفاتيح اختبار', outputs: 'موصل مع حالات فشل', tools: ['مختبر التكامل'], dataAccess: 'عقود التكامل وبيئة Sandbox', ...common, qualityGate: 'الـtimeout وإعادة المحاولة وعدم التسريب مختبرة' },
      { name: 'مراجع الكود', role: 'مراجعة الكود', mission: 'كشف العيوب والمخاطر قبل الدمج', inputs: 'تغيير كود واختبارات', outputs: 'ملاحظات مراجعة مرتبة', tools: ['Code Review Sandbox'], dataAccess: 'Diff المشروع فقط', ...common, qualityGate: 'لا ملاحظات حرجة أو أسرار في diff' },
      { name: 'مهندس DevOps', role: 'تجهيز الإصدار', mission: 'تحضير مسار بناء قابل للتراجع', inputs: 'إصدار معتمد وملفات تشغيل', outputs: 'خطة بناء وإصدار', tools: ['Build Sandbox'], dataAccess: 'ملفات البناء دون أسرار فعلية', ...common, qualityGate: 'Known-good وRollback وHealthcheck جاهزة' },
      { name: 'مختبر القبول', role: 'اختبار قبول المستخدم', mission: 'التحقق من معايير القبول مع سيناريوهات واقعية', inputs: 'قصص المستخدم ونسخة Sandbox', outputs: 'نتائج قبول وعيوب', tools: ['مختبر Regression'], dataAccess: 'بيانات اختبار مجهّلة', ...common, qualityGate: 'كل معيار قبول له نتيجة قابلة للإعادة' },
      { name: 'QA البرمجيات', role: 'بوابة جودة التسليم', mission: 'منع تسليم نسخة غير مستقرة', inputs: 'الكود والاختبارات وتقارير الأمن', outputs: 'قرار QA وإصدار معتمد', tools: ['مختبر Regression', 'Security Review'], dataAccess: 'مخرجات المشروع وسجل التدقيق', ...common, qualityGate: 'Regression وSecurity Review وقبول المستخدم ناجحة', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'commerce',
    name: 'التجارة الإلكترونية',
    english: 'E-commerce',
    manager: 'مدير التجارة الإلكترونية',
    qa: 'QA التجارة الإلكترونية',
    memory: 'كتالوجات وملاحظات السوق',
    queue: 'طلبات المتجر',
    tools: ['مدقق الكتالوج', 'محاكي الطلب'],
    boundary: 'لا شراء أو دفع أو اتصال خارجي تلقائي',
    interface: 'مخرجات موثقة إلى التسويق',
    state: 'Blocked',
    tone: 'amber',
    agentSeeds: [
      { name: 'محلل المنتجات', role: 'تحليل المنتج', mission: 'تقييم وضوح عرض المنتج واحتياجه', inputs: 'وصف المنتج وبيانات السوق', outputs: 'ملخص قيمة ومخاطر', tools: ['محلل المنتجات'], dataAccess: 'كتالوج المجال ومصادر عامة', ...common, qualityGate: 'الادعاءات التجارية قابلة للإسناد' },
      { name: 'مخطط الكتالوج', role: 'هيكلة الكتالوج', mission: 'تنظيم المنتجات والسمات للعرض', inputs: 'قائمة المنتجات وسماتها', outputs: 'مخطط فئات وحقول', tools: ['مدقق الكتالوج'], dataAccess: 'بيانات الكتالوج غير المالية', ...common, qualityGate: 'لا تكرار والحقول الأساسية مكتملة' },
      { name: 'مراجع الأسعار', role: 'مراجعة عرض السعر', mission: 'كشف تناقضات السعر دون اعتماد مالي', inputs: 'أسعار Demo وقواعد العرض', outputs: 'قائمة تناقضات وأسئلة', tools: ['مقارن الأسعار'], dataAccess: 'بيانات سعر تجريبية فقط', ...common, qualityGate: 'أي رقم موسوم كـDemo ومصدره واضح', state: 'Blocked' },
      { name: 'مخطط تجربة الشراء', role: 'تصميم رحلة الشراء', mission: 'اقتراح رحلة شراء واضحة بلا تنفيذ', inputs: 'كتالوج وشرائح مستخدمين', outputs: 'خريطة رحلة ونقاط احتكاك', tools: ['مخطط الرحلة'], dataAccess: 'بيانات تجربة مجهّلة', ...common, qualityGate: 'الحالات الفارغة والخطأ والاسترجاع موصوفة' },
      { name: 'محاكي الطلب', role: 'محاكاة سلة وطلب', mission: 'اختبار سيناريو الطلب داخل Sandbox', inputs: 'كتالوج اختبار وقواعد شحن Demo', outputs: 'سجل محاكاة لا ينشئ طلباً', tools: ['محاكي الطلب'], dataAccess: 'بيانات Sandbox فقط', ...common, qualityGate: 'لا دفع ولا شراء ولا اتصال خارجي' },
      { name: 'مراجع الامتثال التجاري', role: 'مراجعة القيود', mission: 'رصد ادعاءات أو عمليات تتطلب موافقة', inputs: 'محتوى المتجر وتدفقات الطلب', outputs: 'مصفوفة منع وتصعيد', tools: ['قائمة القيود'], dataAccess: 'مخرجات المجال وسجل الموافقات', ...common, qualityGate: 'كل إجراء حساس محجوب ومصعد للمالك', state: 'Blocked' },
      { name: 'QA التجارة الإلكترونية', role: 'بوابة التجارة', mission: 'قبول تجربة المتجر نظرياً دون تشغيل فعلي', inputs: 'مخرجات وكلاء التجارة', outputs: 'قرار QA وملاحظات', tools: ['Regression Sandbox'], dataAccess: 'مساحة المجال فقط', ...common, qualityGate: 'الكتالوج والتجربة والقيود مجتازة', state: 'Blocked', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'marketing',
    name: 'التسويق الكامل',
    english: 'Full Digital Marketing',
    manager: 'مدير التسويق',
    qa: 'QA التسويق',
    memory: 'استراتيجيات وقوالب الحملات',
    queue: 'خطط ومحتوى',
    tools: ['مخطط الحملة', 'محلل التحويل'],
    boundary: 'لا يرسل حملات أو رسائل خارجية دون موافقة',
    interface: 'طلب رسمي إلى التصميم أو المبيعات',
    state: 'Designed',
    tone: 'rose',
    agentSeeds: [
      { name: 'استراتيجي التسويق', role: 'الاستراتيجية التسويقية', mission: 'تحويل الهدف التجاري إلى استراتيجية قابلة للقياس', inputs: 'هدف العمل وشرائح السوق', outputs: 'موجز استراتيجية وأهداف', tools: ['مخطط الحملة'], dataAccess: 'موجز العميل وبيانات السوق المعتمدة', ...common, qualityGate: 'الهدف والجمهور والقناة ومقياس النجاح محددة' },
      { name: 'باحث SEO', role: 'تحسين الظهور', mission: 'اكتشاف فرص بحث عضوي قابلة للتحقق', inputs: 'موضوعات وسياق السوق', outputs: 'خريطة كلمات وفرص محتوى', tools: ['محلل البحث'], dataAccess: 'بيانات بحث عامة ومحتوى العميل', ...common, qualityGate: 'الكلمات والنية والمنافسة موثقة' },
      { name: 'كاتب المحتوى', role: 'إنتاج المحتوى', mission: 'كتابة محتوى مطابق للموجز دون ادعاءات غير مثبتة', inputs: 'موجز ورسالة العلامة ومصادر', outputs: 'مسودة محتوى مع ملاحظات مصدر', tools: ['محرر المحتوى'], dataAccess: 'أصول العلامة ومصادر معتمدة', ...common, qualityGate: 'النبرة والحقائق وCTA متوافقة' },
      { name: 'مخطط الحملات', role: 'تخطيط الحملات', mission: 'بناء خطة حملة بمراحل وفرضيات', inputs: 'استراتيجية وميزانية Demo', outputs: 'خطة قنوات وتجارب', tools: ['مخطط الحملة'], dataAccess: 'بيانات حملة تجريبية لا حسابات إعلانية', ...common, qualityGate: 'الفرضية والجمهور والمقياس والموعد واضحة' },
      { name: 'محلل التحويل', role: 'تحليل مسار التحويل', mission: 'تحليل نقاط التحويل واقتراح تحسينات', inputs: 'بيانات مسار مجهّلة', outputs: 'تحليل Funnel وتوصيات', tools: ['محلل التحويل'], dataAccess: 'Aggregates مجهّلة فقط', ...common, qualityGate: 'التحويلات لا تُعرض كأرقام حية دون مصدر' },
      { name: 'مخطط البريد', role: 'تصميم رسائل داخلية', mission: 'صياغة تسلسل مراسلات جاهز للمراجعة', inputs: 'موجز الحملة وشرائح مشتركة Demo', outputs: 'تسلسل ورسائل مسودة', tools: ['محرر الحملات'], dataAccess: 'قوائم وهمية أو مجهّلة', ...common, qualityGate: 'لا إرسال ولا بيانات شخصية فعلية' },
      { name: 'محلل القنوات', role: 'مقارنة القنوات', mission: 'مقارنة القنوات وفق أهداف ومقاييس محددة', inputs: 'نتائج حملة وفرضيات', outputs: 'مصفوفة قناة وقرار تجريبي', tools: ['لوحة القنوات'], dataAccess: 'تقارير حملة مجهّلة', ...common, qualityGate: 'المقارنة تستخدم نفس الفترة والتعريف' },
      { name: 'مراجع العلامة', role: 'اتساق العلامة', mission: 'فحص التزام المحتوى بقواعد العلامة', inputs: 'مسودة وإرشادات العلامة', outputs: 'ملاحظات اتساق', tools: ['مدقق الهوية'], dataAccess: 'إرشادات وأصول العلامة', ...common, qualityGate: 'المصطلحات والنبرة والهوية متسقة' },
      { name: 'منسق طلبات التسويق', role: 'تنسيق واجهات التسويق', mission: 'تحويل احتياج التسويق إلى طلب مجال واضح', inputs: 'خطة ومخرج مطلوب', outputs: 'Interface Request مسجل', tools: ['سجل الطلبات'], dataAccess: 'بيانات الطلب لا ملفات المجال الآخر', ...common, qualityGate: 'المصدر والسبب والنطاق والمدة محددة' },
      { name: 'QA التسويق', role: 'بوابة التسويق', mission: 'مراجعة الحملة والمحتوى قبل التسليم', inputs: 'كل أصول الحملة وتقاريرها', outputs: 'قرار QA وحزمة تسليم', tools: ['Marketing Regression'], dataAccess: 'سجل المجال وأصوله', ...common, qualityGate: 'لا إرسال خارجي، ومصادر وقياس وموافقة مكتملة', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'design',
    name: 'الجرافيك ديزاين والهوية البصرية',
    english: 'Graphic Design & Brand',
    manager: 'مدير الجرافيك ديزاين',
    qa: 'QA التصميم والهوية',
    memory: 'أصول وإرشادات العلامة',
    queue: 'طلبات التصميم',
    tools: ['Nova Studio', 'مدقق الهوية'],
    boundary: 'أصول العميل لا تخرج من مساحته',
    interface: 'عقد أصول رسمي مع التسويق',
    state: 'Simulated',
    tone: 'violet',
    agentSeeds: [
      { name: 'مصمم الهوية', role: 'تصميم الهوية', mission: 'تحويل شخصية العلامة إلى نظام بصري متسق', inputs: 'موجز العلامة وأصولها', outputs: 'اتجاه بصري وقواعد استخدام', tools: ['Nova Studio'], dataAccess: 'أصول العلامة داخل Workspace', ...common, qualityGate: 'النظام قابل للتطبيق وله قواعد واضحة' },
      { name: 'مصمم المنشورات', role: 'تصميم Social', mission: 'إنتاج مسودات منشورات متوافقة مع القنوات', inputs: 'محتوى معتمد ومقاسات القناة', outputs: 'مقترحات تصميم ونسخ', tools: ['Nova Studio'], dataAccess: 'أصول العميل وموجز الحملة', ...common, qualityGate: 'المقاس والنص والهوية والتباين مجتازة' },
      { name: 'مصمم UI المرئي', role: 'التصميم المرئي للواجهات', mission: 'ترجمة المتطلبات إلى نظام واجهة بصري', inputs: 'مواصفات المنتج ونظام العلامة', outputs: 'لوحات ومكونات UI', tools: ['Nova Studio'], dataAccess: 'ملفات مشروع التصميم فقط', ...common, qualityGate: 'الحالات الأساسية والاستجابة موثقة' },
      { name: 'مجهز الأصول', role: 'تجهيز الملفات', mission: 'تسمية وتصدير الأصول بصيغ صحيحة', inputs: 'تصاميم معتمدة', outputs: 'حزمة أصول منظمة', tools: ['Asset Exporter'], dataAccess: 'مجلد أصول المجال', ...common, qualityGate: 'لا ملفات مفقودة أو أسماء ملتبسة' },
      { name: 'مراجع اتساق العلامة', role: 'مراجعة الهوية', mission: 'منع الانحراف عن دليل العلامة', inputs: 'أصل بصري ودليل الهوية', outputs: 'تقرير اتساق', tools: ['مدقق الهوية'], dataAccess: 'دليل العلامة والأصل المقدم', ...common, qualityGate: 'الألوان والخطوط والمسافات والاستخدام صحيحة' },
      { name: 'مصمم العروض', role: 'تصميم العروض', mission: 'بناء شرائح واضحة ومقروءة للعرض', inputs: 'محتوى العرض وقواعد العلامة', outputs: 'تخطيط شرائح وملاحظات مرئية', tools: ['Nova Studio'], dataAccess: 'محتوى العرض داخل المجال', ...common, qualityGate: 'التسلسل والهرمية وعدم ازدحام النص' },
      { name: 'مخرج الحركة', role: 'تصميم الحركة', mission: 'اقتراح حركة وظيفية لا تشتت المستخدم', inputs: 'تصميم واجهة أو حملة', outputs: 'مخطط حركة وقواعد توقيت', tools: ['Motion Sandbox'], dataAccess: 'نسخ Sandbox من الأصول', ...common, qualityGate: 'الحركة قابلة للإيقاف ومناسبة للأداء' },
      { name: 'QA التصميم والهوية', role: 'بوابة التصميم', mission: 'قبول حزمة التصميم قبل تسليمها لمجال آخر', inputs: 'الأصول والتقرير والإرشادات', outputs: 'قرار QA وحزمة تسليم', tools: ['Brand Regression'], dataAccess: 'كل أصول المجال وسجل التدقيق', ...common, qualityGate: 'الاتساق والملكية والتصدير والعزل مجتازة', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'support',
    name: 'خدمة العملاء',
    english: 'Customer Support',
    manager: 'مدير خدمة العملاء',
    qa: 'QA خدمة العملاء',
    memory: 'معرفة الدعم وتاريخ العميل',
    queue: 'تذاكر الدعم',
    tools: ['مساعد المعرفة', 'مقيس SLA'],
    boundary: 'لا يغيّر بيانات الحساب أو يعوض العميل تلقائياً',
    interface: 'طلب موافقة للحالات الحساسة',
    state: 'Designed',
    tone: 'teal',
    agentSeeds: [
      { name: 'مستقبل الطلبات', role: 'استقبال التذاكر', mission: 'تصنيف طلب العميل وتحديد الأولوية', inputs: 'رسالة العميل وبيانات تذكرة مجهّلة', outputs: 'تذكرة مصنفة وأولوية', tools: ['مساعد المعرفة'], dataAccess: 'محتوى التذكرة فقط', ...common, qualityGate: 'التصنيف واللغة والخصوصية صحيحة' },
      { name: 'محلل المشكلات', role: 'تحليل المشكلة', mission: 'اقتراح سبب وحل ضمن قاعدة المعرفة', inputs: 'تذكرة وسياق المنتج', outputs: 'تشخيص وخطوات مقترحة', tools: ['مساعد المعرفة'], dataAccess: 'قاعدة معرفة المجال وتذكرة العميل', ...common, qualityGate: 'الخطوات قابلة للعكس ولا تتطلب صلاحية حساسة' },
      { name: 'كاتب الردود', role: 'صياغة الرد', mission: 'كتابة رد واضح يحتاج موافقة قبل الإرسال', inputs: 'تشخيص وسياسة الرد', outputs: 'مسودة رد وسياقها', tools: ['محرر الردود'], dataAccess: 'التذكرة وسياسات الدعم', ...common, qualityGate: 'لا وعد أو تعويض أو كشف بيانات بلا اعتماد' },
      { name: 'مقيس SLA', role: 'قياس الخدمة', mission: 'حساب مؤشرات زمن الاستجابة من بيانات مصرح بها', inputs: 'طوابع التذاكر وقواعد SLA', outputs: 'مؤشر SLA وتنبيهات', tools: ['مقيس SLA'], dataAccess: 'بيانات زمنية مجهّلة', ...common, qualityGate: 'الحساب والفترة والاستثناءات موثقة' },
      { name: 'مراجع الحالات الحساسة', role: 'تصعيد حساس', mission: 'اكتشاف الحالات القانونية أو المالية أو الأمنية', inputs: 'تذكرة ومسودة رد', outputs: 'تصنيف تصعيد وطلب موافقة', tools: ['قائمة الحساسية'], dataAccess: 'الحد الأدنى من بيانات التذكرة', ...common, qualityGate: 'كل حالة حساسة متوقفة ومصعدة', state: 'Blocked' },
      { name: 'QA خدمة العملاء', role: 'بوابة الدعم', mission: 'مراجعة جودة الرد والمعالجة قبل التسليم', inputs: 'التذكرة والتشخيص والمسودة', outputs: 'قرار QA وملاحظات', tools: ['Support Regression'], dataAccess: 'سجل المجال دون حسابات خارجية', ...common, qualityGate: 'الدقة والنبرة والخصوصية والتصعيد مجتازة', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'sales',
    name: 'المبيعات وتوليد العملاء',
    english: 'B2B Sales & Lead Generation',
    manager: 'مدير المبيعات',
    qa: 'QA المبيعات',
    memory: 'سجل العملاء المحتملين',
    queue: 'Leads وفرص المبيعات',
    tools: ['مؤهل Lead', 'مخطط الحساب'],
    boundary: 'لا تواصل خارجي دون نطاق وموافقة',
    interface: 'استقبال Lead من التسويق بعقد واضح',
    state: 'Blocked',
    tone: 'amber',
    agentSeeds: [
      { name: 'باحث العملاء', role: 'بحث الحسابات', mission: 'العثور على حسابات محتملة من مصادر مصرح بها', inputs: 'قطاع وسوق ومعايير ICP', outputs: 'قائمة حسابات مع مصدر', tools: ['باحث الحسابات'], dataAccess: 'مصادر أعمال عامة دون بيانات حساسة', ...common, qualityGate: 'المصدر والملاءمة وحداثة البيانات واضحة', state: 'Blocked' },
      { name: 'مؤهل الفرص', role: 'تأهيل Lead', mission: 'تقييم الملاءمة الأولية دون قرار بيع نهائي', inputs: 'بيانات Lead مجهّلة ومعايير ICP', outputs: 'درجة تأهيل وسبب', tools: ['مؤهل Lead'], dataAccess: 'سجل Leads المصرح به', ...common, qualityGate: 'الدرجة قابلة للتفسير ولا تستخدم بيانات حساسة', state: 'Blocked' },
      { name: 'مخطط الحسابات', role: 'تخطيط الحساب', mission: 'بناء خريطة أصحاب المصلحة والاحتياج', inputs: 'ملخص حساب وملاحظات مصرح بها', outputs: 'خريطة حساب وأسئلة اكتشاف', tools: ['مخطط الحساب'], dataAccess: 'ملاحظات الحساب داخل المجال', ...common, qualityGate: 'لا استنتاجات شخصية غير مسندة', state: 'Blocked' },
      { name: 'باحث الاحتياج', role: 'اكتشاف المشكلة', mission: 'صياغة فرضيات احتياج قابلة للتحقق', inputs: 'إشارات الحساب وبيانات السوق', outputs: 'فرضيات وأسئلة مقابلة', tools: ['مصفوفة الاحتياج'], dataAccess: 'مصادر عامة وملاحظات مجهّلة', ...common, qualityGate: 'الفصل بين الحقيقة والفرضية', state: 'Blocked' },
      { name: 'كاتب العرض', role: 'إعداد العرض', mission: 'صياغة مسودة عرض قيمة غير ملزمة', inputs: 'نتائج اكتشاف ومواصفات المنتج', outputs: 'مسودة عرض وأسئلة مفتوحة', tools: ['محرر العروض'], dataAccess: 'مواصفات المنتج المعتمدة', ...common, qualityGate: 'لا سعر أو التزام أو وعد غير معتمد', state: 'Blocked' },
      { name: 'مراجع التواصل', role: 'مراجعة مراسلات البيع', mission: 'فحص رسالة البيع قبل أي إرسال خارجي', inputs: 'مسودة رسالة وسياسة التواصل', outputs: 'قرار قبول أو تصعيد', tools: ['مدقق التواصل'], dataAccess: 'المسودة وسجل الموافقة', ...common, qualityGate: 'الموافقة والنطاق وقائمة المستلمين موجودة', state: 'Blocked' },
      { name: 'QA المبيعات', role: 'بوابة المبيعات', mission: 'مراجعة حزمة Lead أو عرض قبل التسليم', inputs: 'كل مخرجات المبيعات', outputs: 'قرار QA وسجل منع', tools: ['Sales Regression'], dataAccess: 'سجل المجال فقط', ...common, qualityGate: 'لا اتصال خارجي أو التزام تجاري دون موافقة مالك', state: 'Blocked', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'documents',
    name: 'المستندات ومعالجة البيانات',
    english: 'Document & Data Processing',
    manager: 'مدير المستندات',
    qa: 'QA المستندات',
    memory: 'مخططات الحقول وقواعد الاستخراج',
    queue: 'دفعات المعالجة',
    tools: ['مستخرج الحقول', 'مدقق التكرار'],
    boundary: 'الملفات تبقى داخل مساحة العميل',
    interface: 'تسليم محدد إلى BI أو المحاسبة',
    state: 'Designed',
    tone: 'blue',
    agentSeeds: [
      { name: 'مستخرج المستندات', role: 'استخراج النص والحقول', mission: 'استخراج الحقول المطلوبة مع مواضعها', inputs: 'مستندات العميل المصرح بها', outputs: 'حقول مستخرجة مع ثقة', tools: ['مستخرج الحقول'], dataAccess: 'ملفات Workspace فقط', ...common, qualityGate: 'كل حقل مرتبط بصفحة أو موضع' },
      { name: 'مصنف البيانات', role: 'تصنيف البيانات', mission: 'تصنيف الحقول حسب الحساسية والاستخدام', inputs: 'حقول مستخرجة وسياسة التصنيف', outputs: 'سجل تصنيف وRetention', tools: ['مصنف البيانات'], dataAccess: 'Metadata وحقول الحد الأدنى', ...common, qualityGate: 'لا حقل حساس بلا تصنيف' },
      { name: 'مراجع الاكتمال', role: 'فحص الاكتمال', mission: 'كشف الحقول الناقصة أو غير القابلة للقراءة', inputs: 'نتيجة الاستخراج ومخطط الحقول', outputs: 'تقرير اكتمال ونواقص', tools: ['مدقق الاكتمال'], dataAccess: 'نتائج المعالجة لا الملفات غير اللازمة', ...common, qualityGate: 'النقص ومصدره ونسبة الثقة واضحة' },
      { name: 'كاشف التكرار', role: 'كشف التكرار', mission: 'اكتشاف مستندات أو سجلات متكررة', inputs: 'بصمات الملفات وسجلات مجهّلة', outputs: 'قائمة تكرار مرشحة', tools: ['مدقق التكرار'], dataAccess: 'بصمات ومفاتيح داخل المجال', ...common, qualityGate: 'التشابه عتبة مرئية ولا حذف تلقائي' },
      { name: 'QA المستندات', role: 'بوابة المعالجة', mission: 'اعتماد حزمة بيانات قبل تسليمها لمجال آخر', inputs: 'الاستخراج والتصنيف والاكتمال', outputs: 'حزمة تسليم وقرار QA', tools: ['Document Regression'], dataAccess: 'سجل المجال والنتائج', ...common, qualityGate: 'المصدر والحقول والحساسية والعزل مجتازة', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'localization',
    name: 'الترجمة والتوطين',
    english: 'Translation & Localization',
    manager: 'مدير الترجمة والتوطين',
    qa: 'QA الترجمة',
    memory: 'ذاكرة الترجمة والمصطلحات',
    queue: 'حزم الترجمة',
    tools: ['ذاكرة المصطلحات', 'فاحص RTL'],
    boundary: 'لا يخلط ملفات اللغات أو العملاء',
    interface: 'عقد تسليم محتوى مع التصميم',
    state: 'Designed',
    tone: 'violet',
    agentSeeds: [
      { name: 'مترجم أول', role: 'الترجمة الأساسية', mission: 'إنتاج ترجمة دقيقة ضمن السياق', inputs: 'نص مصدر وذاكرة ترجمة', outputs: 'ترجمة مسودة وملاحظات', tools: ['ذاكرة المصطلحات'], dataAccess: 'ملفات اللغة والمشروع فقط', ...common, qualityGate: 'المعنى والمصطلحات والسياق محفوظة' },
      { name: 'مراجع المصطلحات', role: 'ضبط المصطلح', mission: 'توحيد المصطلحات عبر حزمة المحتوى', inputs: 'ترجمة وقاموس مصطلحات', outputs: 'تقرير مصطلحات وتصحيحات', tools: ['ذاكرة المصطلحات'], dataAccess: 'قاموس المجال والنص المقدم', ...common, qualityGate: 'كل مصطلح حساس له قرار موثق' },
      { name: 'مراجع الثقافة', role: 'المراجعة الثقافية', mission: 'كشف عبارات غير مناسبة للسوق المستهدف', inputs: 'نص مترجم وسياق الجمهور', outputs: 'ملاحظات ثقافية', tools: ['مراجع الثقافة'], dataAccess: 'حزمة اللغة وسياق المنتج', ...common, qualityGate: 'الاقتراحات مبررة وليست رقابة غير لازمة' },
      { name: 'فاحص RTL', role: 'فحص اتجاه النص', mission: 'اختبار عرض النص العربي واللغات ثنائية الاتجاه', inputs: 'مخرجات ترجمة وواجهة Sandbox', outputs: 'تقرير RTL وتعارضات', tools: ['فاحص RTL'], dataAccess: 'نسخة Sandbox من الواجهة', ...common, qualityGate: 'لا قص أو انعكاس أو خلط اتجاهات' },
      { name: 'QA الترجمة', role: 'بوابة التوطين', mission: 'اعتماد حزمة اللغة قبل التسليم', inputs: 'الترجمة والمصطلحات والثقافة وRTL', outputs: 'قرار QA وحزمة نهائية', tools: ['Localization Regression'], dataAccess: 'سجل المجال وحزم اللغات', ...common, qualityGate: 'الدقة والاتساق والاتجاه والخصوصية مجتازة', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'education',
    name: 'التعليم والتدريب',
    english: 'Education & Training',
    manager: 'مدير التعليم والتدريب',
    qa: 'QA التعليم',
    memory: 'مناهج وأهداف تعلم',
    queue: 'برامج التدريب',
    tools: ['باني الدروس', 'مدقق التقييم'],
    boundary: 'محتوى المتعلم خاص ومصنف',
    interface: 'تقارير تقدم بموافقة واضحة',
    state: 'Designed',
    tone: 'teal',
    agentSeeds: [
      { name: 'مصمم المنهج', role: 'تصميم المنهج', mission: 'تحويل الهدف التعليمي إلى منهج متدرج', inputs: 'جمهور وأهداف وقيود زمنية', outputs: 'خريطة منهج ووحدات', tools: ['باني الدروس'], dataAccess: 'موجز البرنامج ومصادره', ...common, qualityGate: 'الأهداف قابلة للقياس والتدرج منطقي' },
      { name: 'منشئ الدروس', role: 'إنتاج الدرس', mission: 'إنشاء درس واضح متوافق مع الهدف', inputs: 'خريطة المنهج ومصادر معتمدة', outputs: 'محتوى درس وتمارين', tools: ['باني الدروس'], dataAccess: 'محتوى البرنامج لا ملفات متعلم حساسة', ...common, qualityGate: 'الشرح والنشاط والهدف متطابقة' },
      { name: 'منشئ التقييم', role: 'تصميم التقييم', mission: 'بناء أسئلة تقيس الهدف دون تحيز غير مقصود', inputs: 'أهداف الدرس ومحتواه', outputs: 'تقييم ومفتاح إجابة', tools: ['مدقق التقييم'], dataAccess: 'محتوى الدرس وبيانات اختبار Demo', ...common, qualityGate: 'الأسئلة قابلة للتصحيح ومرتبطة بهدف' },
      { name: 'مراجع التعلم', role: 'مراجعة تربوية', mission: 'فحص وضوح ومناسبة المادة للمتعلمين', inputs: 'درس وتقييم وسياق الجمهور', outputs: 'ملاحظات تعلم', tools: ['قائمة مراجعة التعلم'], dataAccess: 'حزمة المحتوى فقط', ...common, qualityGate: 'المستوى واللغة والإتاحة مناسبة' },
      { name: 'محلل التقدم', role: 'تحليل التقدم', mission: 'تلخيص تقدم مجهّل دون استنتاجات حساسة', inputs: 'نتائج تقييم مجمعة', outputs: 'تقرير تقدم ومخاطر تعلم', tools: ['محلل التقدم'], dataAccess: 'Aggregates مجهّلة', ...common, qualityGate: 'لا كشف لهوية المتعلم ولا قرار عالي المخاطر' },
      { name: 'QA التعليم', role: 'بوابة التدريب', mission: 'اعتماد البرنامج قبل تسليمه', inputs: 'المنهج والدروس والتقييم والتقدم', outputs: 'قرار QA وحزمة تسليم', tools: ['Education Regression'], dataAccess: 'مخرجات المجال وسجل التدقيق', ...common, qualityGate: 'الأهداف والمحتوى والتقييم والخصوصية مجتازة', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'consulting',
    name: 'الاستشارات والتحول الرقمي',
    english: 'Consulting & Digital Transformation',
    manager: 'مدير الاستشارات',
    qa: 'QA الاستشارات',
    memory: 'نماذج التشخيص وخطط التحول',
    queue: 'مشاريع استشارية',
    tools: ['مخطط النضج', 'مصفوفة الأولويات'],
    boundary: 'لا يقدم قراراً قانونياً أو مالياً',
    interface: 'تجميع أدلة من المجالات عبر طلب رسمي',
    state: 'Designed',
    tone: 'rose',
    agentSeeds: [
      { name: 'محلل الحالة', role: 'تشخيص الوضع الحالي', mission: 'تلخيص الوضع الحالي وفجواته من الأدلة', inputs: 'مقابلات ووثائق مصرح بها', outputs: 'تشخيص وأدلة وفجوات', tools: ['قالب التشخيص'], dataAccess: 'ملفات مشروع العميل', ...common, qualityGate: 'الفصل بين الدليل والاستنتاج' },
      { name: 'مخطط التحول', role: 'تخطيط التحول', mission: 'اقتراح مراحل تحول قابلة للتنفيذ', inputs: 'تشخيص وأهداف وقيود', outputs: 'خارطة طريق ومراحل', tools: ['مخطط النضج'], dataAccess: 'مخرجات التشخيص المعتمدة', ...common, qualityGate: 'كل مرحلة لها نتيجة ومالك ومخاطر' },
      { name: 'مقيس النضج', role: 'تقييم النضج', mission: 'تقدير مستوى النضج وفق نموذج موثق', inputs: 'أدلة عملية ومقاييس النموذج', outputs: 'درجة نضج وتعليل', tools: ['مخطط النضج'], dataAccess: 'أدلة العميل داخل المشروع', ...common, qualityGate: 'الدرجة قابلة للتفسير وليست شهادة' },
      { name: 'مخطط الأولويات', role: 'ترتيب المبادرات', mission: 'ترتيب المبادرات وفق قيمة وجهد ومخاطر', inputs: 'قائمة مبادرات وقيود', outputs: 'مصفوفة أولويات', tools: ['مصفوفة الأولويات'], dataAccess: 'ملخصات المبادرات', ...common, qualityGate: 'الأوزان والافتراضات معلنة' },
      { name: 'مراجع التوصيات', role: 'مراجعة التوصية', mission: 'اختبار اتساق التوصية مع الأدلة والحدود', inputs: 'تشخيص وخارطة طريق وتوصية', outputs: 'ملاحظات ومخاطر', tools: ['قائمة التوصيات'], dataAccess: 'حزمة الاستشارة كاملة', ...common, qualityGate: 'لا ادعاء قانوني أو مالي أو ضمان نتيجة' },
      { name: 'QA الاستشارات', role: 'بوابة الاستشارة', mission: 'اعتماد حزمة استشارية قابلة للمراجعة', inputs: 'كل مخرجات المشروع', outputs: 'قرار QA وحزمة تقرير', tools: ['Consulting Regression'], dataAccess: 'سجل المشروع والتدقيق', ...common, qualityGate: 'الأدلة والافتراضات والمخاطر ومجال الرأي واضحة', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'realestate',
    name: 'العقارات',
    english: 'Real Estate',
    manager: 'مدير العقارات',
    qa: 'QA العقارات',
    memory: 'سجل الأصول ومصادر السوق',
    queue: 'بحوث العقارات',
    tools: ['مقارن الأصول', 'مدقق المصدر'],
    boundary: 'لا تقييم رسمي أو تفاوض أو شراء تلقائي',
    interface: 'تقارير معلوماتية فقط',
    state: 'Blocked',
    tone: 'amber',
    agentSeeds: [
      { name: 'باحث السوق العقاري', role: 'بحث السوق العقاري', mission: 'جمع إشارات السوق العقاري من مصادر معلنة', inputs: 'منطقة ونوع أصل ومصادر', outputs: 'موجز سوق ومصادر', tools: ['مدقق المصدر'], dataAccess: 'مصادر عقارية عامة', ...common, qualityGate: 'المصدر والتاريخ والمنطقة موثقة', state: 'Blocked' },
      { name: 'محلل الأصول', role: 'تحليل الأصل', mission: 'وصف خصائص الأصل ومقارناته دون تقييم رسمي', inputs: 'مواصفات أصل ومقارنات', outputs: 'تحليل وصفي', tools: ['مقارن الأصول'], dataAccess: 'بيانات أصل مصرح بها', ...common, qualityGate: 'لا قيمة رسمية أو قرار شراء', state: 'Blocked' },
      { name: 'مقارن الأصول', role: 'مقارنة العقارات', mission: 'مقارنة أصول وفق سمات معلنة', inputs: 'قائمة أصول وسمات', outputs: 'جدول مقارنة', tools: ['مقارن الأصول'], dataAccess: 'بيانات الأصول داخل المجال', ...common, qualityGate: 'نفس المعايير والفترة والمصدر', state: 'Blocked' },
      { name: 'مدقق المصدر العقاري', role: 'تحقق المصدر', mission: 'فحص حداثة ووضوح المصدر العقاري', inputs: 'سجل مصدر ومعلومة', outputs: 'حالة مصدر وثقة', tools: ['مدقق المصدر'], dataAccess: 'سجل المصادر فقط', ...common, qualityGate: 'الرابط والسياق ودرجة الثقة', state: 'Blocked' },
      { name: 'محلل الطلب المحلي', role: 'تحليل الطلب', mission: 'تلخيص مؤشرات الطلب المحلي دون تنبؤ مالي', inputs: 'مؤشرات عامة وبيانات مجهّلة', outputs: 'إشارات طلب وحدود', tools: ['محلل الطلب'], dataAccess: 'Aggregates سوقية', ...common, qualityGate: 'توضيح عدم كونها توصية استثمارية', state: 'Blocked' },
      { name: 'مراجع مخاطر الصفقة', role: 'رصد مخاطر الصفقة', mission: 'تحديد أسئلة ومخاطر تحتاج مختصاً', inputs: 'ملخص أصل وعرض Demo', outputs: 'قائمة أسئلة وتصعيد', tools: ['قائمة المخاطر'], dataAccess: 'ملخصات الصفقة لا عقود تنفيذية', ...common, qualityGate: 'كل خطر مصنف وليس حكماً قانونياً', state: 'Blocked' },
      { name: 'QA العقارات', role: 'بوابة العقارات', mission: 'اعتماد تقرير معلوماتي فقط', inputs: 'بحث ومقارنات ومصادر', outputs: 'قرار QA وحدود الاستخدام', tools: ['Real Estate Regression'], dataAccess: 'سجل المجال', ...common, qualityGate: 'لا تفاوض أو تقييم رسمي أو شراء تلقائي', state: 'Blocked', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'procurement',
    name: 'المقاولات والتوريدات',
    english: 'Contracting & Procurement',
    manager: 'مدير المقاولات والتوريدات',
    qa: 'QA التوريدات',
    memory: 'مواصفات الموردين والعروض',
    queue: 'طلبات التوريد',
    tools: ['مقارن المواصفات', 'مدقق العرض'],
    boundary: 'لا شراء أو التزام مالي تلقائي',
    interface: 'طلب موافقة للمالك قبل التواصل',
    state: 'Blocked',
    tone: 'amber',
    agentSeeds: [
      { name: 'محلل المتطلبات الفنية', role: 'تحليل المواصفات', mission: 'تحويل الاحتياج إلى مواصفات قابلة للمقارنة', inputs: 'احتياج ومخططات مصرح بها', outputs: 'مواصفة فنية وأسئلة', tools: ['مقارن المواصفات'], dataAccess: 'ملفات المشروع الفنية', ...common, qualityGate: 'المواصفات قابلة للقياس وغير متحيزة', state: 'Blocked' },
      { name: 'باحث الموردين', role: 'بحث الموردين', mission: 'جمع موردين محتملين من مصادر معلنة', inputs: 'مواصفة ونطاق جغرافي', outputs: 'قائمة موردين ومصادر', tools: ['باحث الموردين'], dataAccess: 'مصادر موردين عامة', ...common, qualityGate: 'كل مورد موثق ولا يوجد تواصل خارجي', state: 'Blocked' },
      { name: 'مقارن العروض', role: 'مقارنة العرض', mission: 'مقارنة عروض Demo وفق مواصفات موحدة', inputs: 'عروض ومصفوفة متطلبات', outputs: 'جدول مقارنة وفجوات', tools: ['مدقق العرض'], dataAccess: 'عروض داخل Workspace', ...common, qualityGate: 'العملة والشروط ومواطن النقص ظاهرة', state: 'Blocked' },
      { name: 'مراجع العقود', role: 'رصد شروط العقد', mission: 'استخراج نقاط تحتاج مراجعة قانونية', inputs: 'مسودة عقد ومصفوفة شروط', outputs: 'قائمة نقاط وتصعيد', tools: ['مستخرج الشروط'], dataAccess: 'مسودات غير تنفيذية', ...common, qualityGate: 'لا يقدم رأياً قانونياً أو يوافق عقداً', state: 'Blocked' },
      { name: 'مقدر التكلفة التجريبي', role: 'تقدير نطاق التكلفة', mission: 'حساب نطاق تجريبي مبني على افتراضات', inputs: 'كميات ومؤشرات Demo', outputs: 'نطاق تكلفة وافتراضات', tools: ['حاسبة النطاق'], dataAccess: 'بيانات تكلفة تجريبية', ...common, qualityGate: 'النطاق لا يتحول إلى التزام مالي', state: 'Blocked' },
      { name: 'منسق طلب الشراء', role: 'تجهيز طلب الموافقة', mission: 'تجميع ملف قرار الشراء للمالك', inputs: 'مقارنة ومخاطر ومواصفات', outputs: 'Approval Request كامل', tools: ['منشئ الموافقات'], dataAccess: 'مخرجات التوريد المعتمدة', ...common, qualityGate: 'المبلغ والنطاق والمالك والمخاطر محددة', state: 'Blocked' },
      { name: 'مراجع المخاطر التشغيلية', role: 'مراجعة مخاطر التوريد', mission: 'كشف الاعتماديات والمخاطر التشغيلية', inputs: 'مقارنة المورد وخطة التوريد', outputs: 'مصفوفة مخاطر', tools: ['مصفوفة المخاطر'], dataAccess: 'ملخصات عروض ومواصفات', ...common, qualityGate: 'التخفيف والمالك وشرط الإيقاف واضح', state: 'Blocked' },
      { name: 'QA التوريدات', role: 'بوابة التوريد', mission: 'اعتماد ملف قرار غير تنفيذي', inputs: 'كل مخرجات التوريد', outputs: 'قرار QA وتسليم للمالك', tools: ['Procurement Regression'], dataAccess: 'سجل المجال', ...common, qualityGate: 'لا شراء أو تواصل أو التزام قبل موافقة صريحة', state: 'Blocked', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'accounting',
    name: 'المحاسبة والعمليات المحاسبية',
    english: 'Accounting Operations',
    manager: 'مدير المحاسبة',
    qa: 'QA المحاسبة',
    memory: 'دفاتر وخرائط الحسابات',
    queue: 'فواتير ومطابقات',
    tools: ['مستخرج الفواتير', 'مقارن القيود'],
    boundary: 'البيانات المحاسبية منفصلة؛ الضرائب معلومات مساعدة فقط',
    interface: 'مخرجات للمراجعة البشرية المختصة',
    state: 'Blocked',
    tone: 'rose',
    agentSeeds: [
      { name: 'مستخرج الفواتير', role: 'استخراج الفواتير', mission: 'استخراج بيانات الفاتورة مع مصدر كل حقل', inputs: 'فواتير داخل Workspace', outputs: 'سجل فاتورة ودرجة ثقة', tools: ['مستخرج الفواتير'], dataAccess: 'ملفات فواتير المجال فقط', ...common, qualityGate: 'المبلغ والعملة والتاريخ والمورد موثقة', state: 'Blocked' },
      { name: 'مراجع القيود', role: 'مراجعة القيد', mission: 'اقتراح مطابقة القيد مع المستند دون ترحيل', inputs: 'قيد ومسند ومخطط حسابات', outputs: 'اقتراح مطابقة وفجوات', tools: ['مقارن القيود'], dataAccess: 'مسودات قيود ومستندات', ...common, qualityGate: 'لا كتابة في دفتر الإنتاج ولا اعتماد', state: 'Blocked' },
      { name: 'محلل المصروفات', role: 'تحليل المصروفات', mission: 'تصنيف المصروفات واكتشاف الشذوذ الوصفي', inputs: 'قيود مجهّلة وقواعد تصنيف', outputs: 'ملخص مصروفات وتنبيهات', tools: ['محلل المصروفات'], dataAccess: 'بيانات محاسبية مصنفة', ...common, qualityGate: 'كل تنبيه قابل للتتبع ولا حكم احتيال', state: 'Blocked' },
      { name: 'مراجع المطابقة', role: 'المطابقة المحاسبية', mission: 'فحص توافق المستند والقيد والدفعة التجريبية', inputs: 'مستندات وقيود Demo', outputs: 'قائمة مطابقات واستثناءات', tools: ['مقارن القيود'], dataAccess: 'حزمة المطابقة داخل المجال', ...common, qualityGate: 'الاستثناءات لا تُغلق تلقائياً', state: 'Blocked' },
      { name: 'مساعد الامتثال المحاسبي', role: 'رصد متطلبات الامتثال', mission: 'تجميع أسئلة امتثال تحتاج محاسباً مختصاً', inputs: 'مخرجات المحاسبة وسياسة العميل', outputs: 'مذكرة أسئلة وتصعيد', tools: ['قائمة الامتثال'], dataAccess: 'ملخصات محاسبية دون قرار نهائي', ...common, qualityGate: 'لا استشارة ضريبية أو قانونية نهائية', state: 'Blocked' },
      { name: 'محلل التدفق النقدي التجريبي', role: 'تحليل التدفق', mission: 'تلخيص حركة نقدية تاريخية مجهّلة', inputs: 'بيانات تاريخية مصنفة', outputs: 'ملخص تدفق وافتراضات', tools: ['محلل التدفق'], dataAccess: 'Aggregates محاسبية', ...common, qualityGate: 'لا توقع أو قرار تمويلي ملزم', state: 'Blocked' },
      { name: 'مراجع فصل الصلاحيات', role: 'رقابة الصلاحيات', mission: 'كشف تعارض الصلاحيات داخل العمليات المحاسبية', inputs: 'مصفوفة أدوار وسير عمل', outputs: 'تقرير فصل صلاحيات', tools: ['مدقق الصلاحيات'], dataAccess: 'Metadata الأدوار فقط', ...common, qualityGate: 'كل تعارض مصعد ولا تعديل تلقائي', state: 'Blocked' },
      { name: 'QA المحاسبة', role: 'بوابة المحاسبة', mission: 'مراجعة المخرجات قبل المختص البشري', inputs: 'الاستخراج والمطابقة والتحليل', outputs: 'قرار QA وإحالة', tools: ['Accounting Regression'], dataAccess: 'سجل المجال', ...common, qualityGate: 'لا ترحيل أو دفع أو رأي ضريبي دون مختص', state: 'Blocked', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'cyber',
    name: 'الأمن السيبراني الدفاعي',
    english: 'Defensive Cybersecurity',
    manager: 'قائد Guard Commander',
    qa: 'QA الأمن الدفاعي',
    memory: 'Findings وسجل الحوادث',
    queue: 'تنبيهات وفحوص',
    tools: ['فاحص التبعيات', 'مختبر Sandbox'],
    boundary: 'دفاعي فقط؛ الاختبارات المصرح بها بنطاق محدد',
    interface: 'يُبلغ Nova Eye والمالك',
    state: 'Simulated',
    tone: 'teal',
    agentSeeds: [
      { name: 'حارس سلامة الكود', role: 'فحص أمن الكود', mission: 'رصد أنماط كود خطرة في نطاق مصرح', inputs: 'Diff أو مستودع Sandbox', outputs: 'Findings مع شدة ودليل', tools: ['فاحص الكود'], dataAccess: 'كود Sandbox فقط', ...common, qualityGate: 'كل Finding قابل لإعادة الإنتاج ولا تعديل تلقائي', state: 'Simulated' },
      { name: 'حارس السلوك', role: 'تحليل السلوك', mission: 'اكتشاف سلوك غير متوقع في بيئة معزولة', inputs: 'سجلات Sandbox وسيناريو اختبار', outputs: 'تنبيه سلوكي وسياق', tools: ['Behavior Sandbox'], dataAccess: 'سجلات اختبار غير إنتاجية', ...common, qualityGate: 'لا تنفيذ هجومي أو اتصال خارج النطاق', state: 'Simulated' },
      { name: 'حارس البرمجيات الخبيثة', role: 'تحليل ملفات دفاعي', mission: 'تصنيف ملف مشتبه به دون تشغيل خطر', inputs: 'بصمة أو ملف معزول', outputs: 'نتيجة تصنيف وحدود ثقة', tools: ['Malware Sandbox'], dataAccess: 'حاوية ملفات معزولة', ...common, qualityGate: 'لا إخراج ملف أو تشغيل خارج Sandbox', state: 'Simulated' },
      { name: 'حارس الثغرات', role: 'رصد الثغرات', mission: 'ترتيب ثغرات معروفة في مكونات مصرح بها', inputs: 'قائمة تبعيات وإصدارات', outputs: 'تقرير ثغرات وأولوية', tools: ['فاحص التبعيات'], dataAccess: 'Manifest وإصدارات فقط', ...common, qualityGate: 'الإصدار والمصدر ودرجة الشدة موثقة', state: 'Simulated' },
      { name: 'حارس التدقيق', role: 'تدقيق الوصول', mission: 'فحص أحداث الوصول والتغييرات الحساسة', inputs: 'Audit Events مجهّلة', outputs: 'تقرير شذوذ وتصعيد', tools: ['Audit Explorer'], dataAccess: 'سجلات التدقيق الأمنية', ...common, qualityGate: 'لا اتهام دون دليل وسياق زمني', state: 'Simulated' },
      { name: 'محقق الحوادث', role: 'الاستجابة التحليلية', mission: 'بناء خط زمني لحادث دفاعي دون احتواء تلقائي', inputs: 'تنبيهات وسجلات مصرح بها', outputs: 'خط زمني وفرضيات', tools: ['Incident Timeline'], dataAccess: 'سجلات الحادث داخل المجال', ...common, qualityGate: 'فصل الحقائق عن الفرضيات وطلب موافقة الإجراء', state: 'Simulated' },
      { name: 'مراجع نموذج التهديد', role: 'Threat Modeling', mission: 'تحديد مسارات تهديد وضوابط وقائية', inputs: 'معمارية ونطاق النظام', outputs: 'نموذج تهديد وأولويات', tools: ['Threat Modeler'], dataAccess: 'معمارية Sandbox ومواصفات', ...common, qualityGate: 'لا تفاصيل هجومية قابلة للاستخدام خارج النطاق', state: 'Simulated' },
      { name: 'QA الأمن الدفاعي', role: 'بوابة الأمن', mission: 'اعتماد تقرير أمني دفاعي وإحالته للمالك', inputs: 'Findings واختبارات وسجل نطاق', outputs: 'قرار QA وتصعيد', tools: ['Security Regression'], dataAccess: 'سجل الأمن ونتائج Sandbox', ...common, qualityGate: 'النطاق والتفويض والأدلة وخطة الإصلاح واضحة', state: 'Simulated', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'qa',
    name: 'اختبار الأنظمة والـAI والجودة',
    english: 'Systems, AI & QA',
    manager: 'مدير اختبار الأنظمة والجودة',
    qa: 'QA مستقل للمنظومة',
    memory: 'حالات الاختبار ونتائجها',
    queue: 'خطط واختبارات',
    tools: ['مقارن النتائج', 'مشغل Regression'],
    boundary: 'يختبر نسخاً معزولة ولا يعتمد النتيجة وحدها',
    interface: 'بوابات تسليم لكل Domain',
    state: 'Simulated',
    tone: 'blue',
    agentSeeds: [
      { name: 'مختبر الوظائف', role: 'اختبار الوظائف', mission: 'التحقق من السلوك الوظيفي المتوقع', inputs: 'متطلبات ونسخة Sandbox', outputs: 'نتائج حالات اختبار', tools: ['مشغل الاختبارات'], dataAccess: 'بيانات اختبار فقط', ...common, qualityGate: 'الحالات الأساسية والحدية موثقة' },
      { name: 'مراجع مخرجات AI', role: 'تقييم مخرجات الذكاء الاصطناعي', mission: 'فحص الدقة والهلوسة والالتزام بالنطاق', inputs: 'Prompt ومخرج ومعيار مرجعي', outputs: 'تقييم وملاحظات', tools: ['مقارن النتائج'], dataAccess: 'عينات غير حساسة', ...common, qualityGate: 'النتيجة قابلة للمقارنة وقيودها معلنة' },
      { name: 'مختبر Regression', role: 'اختبار الانحدار', mission: 'مقارنة النسخة الحالية بـKnown-good', inputs: 'نسختان وحالات اختبار', outputs: 'تقرير فروق وقرار', tools: ['مشغل Regression'], dataAccess: 'Sandbox وFixtures', ...common, qualityGate: 'لا تغيير غير مفسر في الحالات الحرجة' },
      { name: 'مراجع القبول', role: 'اختبار القبول', mission: 'مراجعة قابلية التسليم من منظور المستخدم', inputs: 'معايير قبول ومخرج', outputs: 'قرار قبول وملاحظات', tools: ['Acceptance Runner'], dataAccess: 'حزمة المنتج في Sandbox', ...common, qualityGate: 'كل معيار له دليل واضح' },
      { name: 'اختبار الحدود', role: 'اختبار العزل', mission: 'التأكد من رفض الوصول بين المجالات', inputs: 'سياسات وصلاحيات وطلبات تجريبية', outputs: 'نتيجة Boundary Test', tools: ['Boundary Simulator'], dataAccess: 'Metadata الصلاحيات فقط', ...common, qualityGate: 'كل طلب غير مصرح مرفوض ومسجل', state: 'Simulated' },
      { name: 'QA مستقل للمنظومة', role: 'بوابة الجودة المستقلة', mission: 'منح إشارة جاهزية دون تجاوز مالك المجال', inputs: 'تقارير كل الاختبارات', outputs: 'تقرير جودة مستقل', tools: ['QA Control Room'], dataAccess: 'نتائج الاختبارات لا ملفات العملاء', ...common, qualityGate: 'التعارض مصعد والاعتماد النهائي بشري', state: 'Simulated', tier: 'Primary' },
    ],
  }),
  createDomain({
    id: 'news',
    name: 'الأخبار ومراقبة المعلومات',
    english: 'News & Information Monitoring',
    manager: 'مدير مراقبة الأخبار',
    qa: 'QA الأخبار والمعلومات',
    memory: 'بصمات المصادر والإصدارات',
    queue: 'إشارات ومصادر',
    tools: ['ذاكرة البحث', 'كاشف التشابه'],
    boundary: 'لا اعتبار للمعلومة حقيقة دون مصدر',
    interface: 'تسليم إشارات لأبحاث السوق',
    state: 'Simulated',
    tone: 'violet',
    agentSeeds: [
      { name: 'راصد الأخبار', role: 'رصد الأخبار', mission: 'التقاط أخبار مرتبطة بنطاق مراقبة محدد', inputs: 'موضوع ومصادر عامة مصرح بها', outputs: 'إشارات خبرية مع وقت', tools: ['ذاكرة البحث'], dataAccess: 'مصادر عامة مفهرسة', ...common, qualityGate: 'الرابط والوقت والموضوع واضحة', state: 'Simulated' },
      { name: 'محقق المصدر', role: 'تحقق المصدر', mission: 'تقييم موثوقية وسياق الخبر', inputs: 'خبر ومصدر ونسخ سابقة', outputs: 'بطاقة مصدر ودرجة ثقة', tools: ['مدقق المصدر'], dataAccess: 'سجل مصادر المجال', ...common, qualityGate: 'فصل الخبر عن الرأي والتكهن', state: 'Simulated' },
      { name: 'مزيل التكرار', role: 'إزالة التكرار', mission: 'تجميع التغطيات المتشابهة دون حذف الدليل', inputs: 'إشارات وبصمات نصية', outputs: 'عنقود أخبار ومصادره', tools: ['كاشف التشابه'], dataAccess: 'بصمات ومقتطفات فقط', ...common, qualityGate: 'الخبر الأصلي والتغطيات محفوظة', state: 'Simulated' },
      { name: 'محلل الأثر', role: 'تحليل صلة الخبر', mission: 'شرح الأثر المحتمل على نطاق العمل دون توقعات', inputs: 'خبر محقق وسياق مجال', outputs: 'ملخص صلة وأسئلة متابعة', tools: ['مصفوفة الأثر'], dataAccess: 'خبر محقق وسياق غير حساس', ...common, qualityGate: 'لا يقدم الخبر كحقيقة تشغيلية دون اعتماد', state: 'Simulated' },
      { name: 'QA الأخبار والمعلومات', role: 'بوابة المعلومات', mission: 'اعتماد إشارة موثقة قبل إحالتها لأبحاث السوق', inputs: 'الإشارة وبطاقة المصدر والتكرار', outputs: 'قرار QA وحزمة إحالة', tools: ['News Regression'], dataAccess: 'سجل المجال', ...common, qualityGate: 'المصدر والتاريخ والتكرار والحدود مكتملة', state: 'Simulated', tier: 'Primary' },
    ],
  }),
];

export const totalAgentCount = domainDefinitions.reduce((sum, domain) => sum + domain.agents.length, 0);
export const agentMap = domainDefinitions.flatMap((domain) => domain.agents.map((agent) => ({ domain, agent })));

export const platformModules = [
  { label: 'General Manager', state: 'Designed', detail: 'تنسيق أعلى عبر Interface مسجل دون وصول عام' },
  { label: 'Nova Eye', state: 'Designed', detail: 'مراقبة مستقلة للحدود والتداخل والحالات' },
  { label: 'Guard Commander', state: 'Simulated', detail: 'تنسيق أمني دفاعي مع حراس المجال' },
  { label: 'King Commander', state: 'Designed', detail: 'طبقة أمن وبحث مستقلة وليست مجالاً تجارياً' },
  { label: 'Failover & Recovery', state: 'Simulated', detail: 'Primary وStandby وCold Backup مع Checkpoints' },
  { label: 'Sandbox & Regression', state: 'Simulated', detail: 'اختبارات معزولة ومقارنة Known-good Versions' },
  { label: 'Secrets Vault', state: 'Blocked', detail: 'لا مفاتيح داخل الوكلاء؛ الوصول محجوب حتى تفعيل آمن' },
  { label: 'Emergency Stop', state: 'Designed', detail: 'إيقاف شامل وإيقاف مجال وإيقاف Agent' },
  { label: 'Recovery Drills', state: 'Designed', detail: 'Day of Reckoning واختبارات تداخل وفشل' },
];