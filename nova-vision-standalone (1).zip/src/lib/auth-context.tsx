import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from 'react';

export type OwnerAuthState = {
  loading: boolean;
  available: boolean;
  configured: boolean;
  authenticated: boolean;
  owner: { email: string } | null;
};

type OwnerAuthContextValue = OwnerAuthState & {
  error: string;
  refresh: () => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
};

const initialState: OwnerAuthState = {
  loading: true,
  available: false,
  configured: false,
  authenticated: false,
  owner: null,
};

const OwnerAuthContext = createContext<OwnerAuthContextValue | null>(null);

async function readError(response: Response) {
  const body = await response.json().catch(() => ({}));
  return typeof body.error === 'string' ? body.error : 'REQUEST_FAILED';
}

export function OwnerAuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<OwnerAuthState>(initialState);
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    try {
      const response = await fetch('/api/auth/session', {
        credentials: 'same-origin',
        cache: 'no-store',
      });
      if (!response.ok) throw new Error('SERVER_UNAVAILABLE');
      const session = await response.json();
      setState({
        loading: false,
        available: true,
        configured: session.configured === true,
        authenticated: session.authenticated === true,
        owner: session.authenticated === true && typeof session.owner?.email === 'string'
          ? { email: session.owner.email }
          : null,
      });
    } catch {
      setState({
        loading: false,
        available: false,
        configured: false,
        authenticated: false,
        owner: null,
      });
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const signIn = useCallback(async (email: string, password: string) => {
    setError('');
    const response = await fetch('/api/auth/sign-in', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    if (!response.ok) {
      const code = await readError(response);
      const message = code === 'OWNER_AUTH_NOT_CONFIGURED'
        ? 'لم يتم إعداد مصادقة المالك في أسرار التشغيل.'
        : code === 'SIGN_IN_RATE_LIMITED'
          ? 'محاولات كثيرة؛ انتظر قليلًا ثم أعد المحاولة.'
          : 'تعذر تسجيل الدخول. تحقق من البيانات وحاول مجددًا.';
      setError(message);
      throw new Error(message);
    }
    await refresh();
  }, [refresh]);

  const signOut = useCallback(async () => {
    setError('');
    const response = await fetch('/api/auth/sign-out', {
      method: 'POST',
      credentials: 'same-origin',
    });
    if (!response.ok) throw new Error('تعذر إنهاء الجلسة.');
    await refresh();
  }, [refresh]);

  const value = useMemo(
    () => ({ ...state, error, refresh, signIn, signOut }),
    [state, error, refresh, signIn, signOut],
  );

  return <OwnerAuthContext.Provider value={value}>{children}</OwnerAuthContext.Provider>;
}

export function useOwnerAuth() {
  const value = useContext(OwnerAuthContext);
  if (!value) throw new Error('useOwnerAuth must be used inside OwnerAuthProvider.');
  return value;
}

export function OwnerSignInScreen() {
  const { signIn, error, refresh } = useOwnerAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [pending, setPending] = useState(false);
  const [localError, setLocalError] = useState('');

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setLocalError('');
    try {
      await signIn(email.trim(), password);
      setPassword('');
      await refresh();
    } catch {
      setLocalError('تعذر تسجيل الدخول. تحقق من البيانات وحاول مجددًا.');
    } finally {
      setPending(false);
    }
  }

  return (
    <main className="owner-auth-screen" dir="rtl" lang="ar">
      <section className="owner-auth-card" aria-labelledby="owner-auth-heading">
        <div className="owner-auth-emblem">NV</div>
        <p className="owner-auth-kicker">Nova Vision · Owner access</p>
        <h1 id="owner-auth-heading">تسجيل دخول المالك</h1>
        <p className="owner-auth-intro">
          لوحة المالك محمية. لا يوجد تسجيل عام أو إنشاء تلقائي للحساب.
          <span>Owner dashboard access is restricted. Public registration is disabled.</span>
        </p>
        <form className="owner-auth-form" onSubmit={handleSubmit}>
          <label htmlFor="owner-email">البريد الإلكتروني · Email</label>
          <input
            id="owner-email"
            type="email"
            autoComplete="username"
            maxLength={320}
            required
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            dir="ltr"
          />
          <label htmlFor="owner-password">كلمة المرور · Password</label>
          <input
            id="owner-password"
            type="password"
            autoComplete="current-password"
            minLength={14}
            maxLength={128}
            required
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            dir="ltr"
          />
          {(localError || error) && (
            <p className="owner-auth-error" role="alert">{localError || error}</p>
          )}
          <button className="owner-auth-submit" type="submit" disabled={pending}>
            {pending ? 'جارٍ التحقق… · Verifying…' : 'دخول آمن · Sign in'}
          </button>
        </form>
        <p className="owner-auth-footnote">
          بيانات الدخول تُضبط يدويًا عبر أسرار التشغيل فقط؛ لا تُرسلها في المحادثة.
          <span>Credentials are configured through runtime secrets, never in source files.</span>
        </p>
      </section>
    </main>
  );
}
