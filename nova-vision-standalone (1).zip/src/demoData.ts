import { BrainCircuit, Compass, FileSearch, Gauge, type LucideIcon, Target } from 'lucide-react';

export type OpportunityStage = 'discovery' | 'research' | 'validation' | 'ready';
export type TaskStatus = 'queued' | 'in_progress' | 'done';
export type ApprovalDecision = 'approved' | 'rejected';

export type DashboardSnapshot = {
  mission: {
    short: string;
    vision: string;
    statement: string;
    principles: string[];
  };
  metrics: {
    readiness: number;
    activeAgents: number;
    totalAgents: number;
    opportunities: number;
    researchQueued: number;
    validationsPassed: number;
    validationsTotal: number;
    openTasks: number;
  };
  agents: {
    id: string;
    name: string;
    role: string;
    activity: string;
    status: 'active' | 'standby';
    statusLabel: string;
    tone: string;
    Icon: LucideIcon;
  }[];
  opportunityStages: { id: OpportunityStage; label: string }[];
  opportunities: {
    id: string;
    title: string;
    sector: string;
    market: string;
    source: string;
    fit: number;
    stage: OpportunityStage;
    mark: string;
    tone: string;
  }[];
  research: {
    id: string;
    title: string;
    summary: string;
    source: string;
    updated: string;
    priority: 'high' | 'medium' | 'low';
    priorityLabel: string;
    status: 'queued' | 'review' | 'working';
    statusLabel: string;
  }[];
  validations: {
    id: string;
    title: string;
    detail: string;
    status: 'passed' | 'review' | 'queued';
    statusLabel: string;
  }[];
  tasks: {
    id: string;
    title: string;
    project: string;
    owner: string;
    ownerInitials: string;
    ownerTone: string;
    priority: 'high' | 'medium' | 'low';
    priorityLabel: string;
    due: string;
    status: TaskStatus;
  }[];
  approvals: {
    id: string;
    category: string;
    title: string;
    rationale: string;
    submitted: string;
    owner: string;
    ownerInitials: string;
    ownerTone: string;
    reference: string;
    tone: string;
  }[];
};

const demoSnapshot: DashboardSnapshot = {
  mission: {
    short: 'نحوّل الذكاء الاصطناعي إلى قدرة عملية تدعم نمواً أذكى، مع بقاء الإنسان في قلب كل قرار.',
    vision: 'تمكين الفرق الطموحة من رؤية الفرص بصورة أوضح، وفهم أسواقها بعمق أكبر، والتحرك بثقة ومسؤولية.',
    statement: 'ننسّق بين وكلاء متخصصين لجمع الإشارات، وصياغة الفرضيات، واختبارها — ثم نترك القرار النهائي للإنسان.',
    principles: ['الإنسان أولاً', 'الشفافية قبل السرعة', 'التجربة قبل التوسع'],
  },
  metrics: {
    readiness: 92,
    activeAgents: 4,
    totalAgents: 5,
    opportunities: 8,
    researchQueued: 12,
    validationsPassed: 4,
    validationsTotal: 6,
    openTasks: 7,
  },
  agents: [
    { id: 'scout', name: 'راصد السوق', role: 'اكتشاف الإشارات والاتجاهات', activity: 'يراقب إشارات السوق', status: 'active', statusLabel: 'نشط تجريبياً', tone: 'teal', Icon: Compass },
    { id: 'researcher', name: 'محلل الأبحاث', role: 'جمع الأدلة ومقارنة المصادر', activity: 'يراجع ملخصات السوق', status: 'active', statusLabel: 'نشط تجريبياً', tone: 'violet', Icon: FileSearch },
    { id: 'strategist', name: 'مخطط الفرص', role: 'ترتيب الفرضيات والأولويات', activity: 'يرتب الفرص الأولية', status: 'active', statusLabel: 'نشط تجريبياً', tone: 'blue', Icon: Target },
    { id: 'validator', name: 'مدقق الجاهزية', role: 'فحوص أولية للمخاطر والملاءمة', activity: 'ينتظر مدخلات إضافية', status: 'active', statusLabel: 'نشط تجريبياً', tone: 'amber', Icon: Gauge },
    { id: 'coordinator', name: 'منسق سير العمل', role: 'تجميع المخرجات للمراجعة', activity: 'جاهز عند الحاجة', status: 'standby', statusLabel: 'استعداد تجريبي', tone: 'slate', Icon: BrainCircuit },
  ],
  opportunityStages: [
    { id: 'discovery', label: 'اكتشاف' },
    { id: 'research', label: 'بحث' },
    { id: 'validation', label: 'تحقق' },
    { id: 'ready', label: 'مراجعة بشرية' },
  ],
  opportunities: [
    { id: 'opp-01', title: 'مساعد عمليات للعيادات', sector: 'تقنيات صحية', market: 'مصر · الخليج', source: 'إشارة سوقية', fit: 86, stage: 'validation', mark: 'ص', tone: 'teal' },
    { id: 'opp-02', title: 'منصة ذكاء للمخزون', sector: 'تجارة التجزئة', market: 'مصر', source: 'بحث أولي', fit: 78, stage: 'research', mark: 'ت', tone: 'violet' },
    { id: 'opp-03', title: 'أتمتة خدمات الأعمال', sector: 'خدمات مهنية', market: 'الشرق الأوسط', source: 'مقابلات تجريبية', fit: 72, stage: 'discovery', mark: 'أ', tone: 'amber' },
    { id: 'opp-04', title: 'مساعد معرفة للشركات', sector: 'برمجيات أعمال', market: 'الخليج', source: 'اتجاه تقني', fit: 91, stage: 'ready', mark: 'م', tone: 'blue' },
  ],
  research: [
    { id: 'research-01', title: 'تبنّي الأتمتة الذكية في الشركات الصغيرة', summary: 'مراجعة احتياجات الفرق والمهام الأكثر تكراراً في عينة افتراضية من السوق.', source: 'ملخص تجريبي', updated: 'منذ ساعتين', priority: 'high', priorityLabel: 'أولوية عالية', status: 'review', statusLabel: 'بانتظار مراجعة' },
    { id: 'research-02', title: 'مشهد حلول إدارة المخزون الإقليمية', summary: 'مقارنة أولية للفجوات المحتملة وتجربة المستخدم في حلول التجزئة.', source: 'إشارة افتراضية', updated: 'اليوم', priority: 'medium', priorityLabel: 'متوسطة', status: 'working', statusLabel: 'قيد التحليل' },
    { id: 'research-03', title: 'احتياجات العيادات في تنسيق المواعيد', summary: 'صياغة أسئلة بحث لاختبار فرضيات سير العمل، من دون جمع بيانات حقيقية.', source: 'فرضية داخلية', updated: 'أمس', priority: 'low', priorityLabel: 'عادية', status: 'queued', statusLabel: 'في قائمة الانتظار' },
  ],
  validations: [
    { id: 'val-01', title: 'وضوح المشكلة', detail: 'صياغة حاجة محددة قابلة للاختبار', status: 'passed', statusLabel: 'اجتاز العرض التجريبي' },
    { id: 'val-02', title: 'إشارة طلب أولية', detail: 'توجد فرضية طلب بحاجة لمصدر مستقل', status: 'review', statusLabel: 'تحتاج مراجعة' },
    { id: 'val-03', title: 'ملاءمة الحل', detail: 'توافق أولي بين المشكلة والحل المقترح', status: 'passed', statusLabel: 'اجتاز العرض التجريبي' },
    { id: 'val-04', title: 'توفر مصادر موثوقة', detail: 'بعض الإشارات التجريبية تحتاج تحققاً', status: 'review', statusLabel: 'تحتاج مراجعة' },
    { id: 'val-05', title: 'مراجعة المخاطر', detail: 'قائمة أولية غير مكتملة — لا تغني عن المختصين', status: 'queued', statusLabel: 'لم يبدأ' },
    { id: 'val-06', title: 'الجاهزية البشرية', detail: 'تحديد صاحب القرار والخطوة التالية', status: 'passed', statusLabel: 'اجتاز العرض التجريبي' },
  ],
  tasks: [
    { id: 'task-01', title: 'صياغة أسئلة مقابلات العملاء', project: 'مساعد عمليات للعيادات', owner: 'ليلى حسن', ownerInitials: 'LH', ownerTone: 'rose', priority: 'high', priorityLabel: 'عالية', due: '٢٦ سبتمبر', status: 'in_progress' },
    { id: 'task-02', title: 'مراجعة مصادر اتجاهات السوق', project: 'مسار الأبحاث', owner: 'عمر سامي', ownerInitials: 'OS', ownerTone: 'blue', priority: 'medium', priorityLabel: 'متوسطة', due: '٢٨ سبتمبر', status: 'queued' },
    { id: 'task-03', title: 'تحديث مصفوفة الفرضيات', project: 'منصة ذكاء للمخزون', owner: 'مريم عادل', ownerInitials: 'MA', ownerTone: 'green', priority: 'medium', priorityLabel: 'متوسطة', due: '٢٩ سبتمبر', status: 'in_progress' },
    { id: 'task-04', title: 'توثيق معايير التحقق الأولية', project: 'حوكمة المنظومة', owner: 'كريم ناصر', ownerInitials: 'KN', ownerTone: 'amber', priority: 'low', priorityLabel: 'عادية', due: '٣٠ سبتمبر', status: 'queued' },
  ],
  approvals: [
    { id: 'approval-01', category: 'استراتيجية', title: 'إعطاء أولوية بحثية لمسار تقنيات العيادات', rationale: 'اقتراح تخصيص دورة بحث تجريبية إضافية لفهم مشكلة تنسيق المواعيد قبل أي التزام.', submitted: 'اليوم · ١٠:٤٥ ص', owner: 'مخطط الفرص', ownerInitials: 'OP', ownerTone: 'violet', reference: 'NV-021', tone: 'violet' },
    { id: 'approval-02', category: 'شراكة', title: 'استكشاف تعاون بحثي مع حاضنة أعمال', rationale: 'بدء محادثة استكشافية غير ملزمة للتعرّف على احتياجات الشركات الناشئة.', submitted: 'أمس · ٠٣:٢٠ م', owner: 'راصد السوق', ownerInitials: 'MS', ownerTone: 'teal', reference: 'NV-019', tone: 'teal' },
    { id: 'approval-03', category: 'أولوية', title: 'مراجعة فرضية ذكاء المخزون قبل التوسع', rationale: 'طلب جلسة مراجعة بشرية للتحقق من افتراضات السوق والمصادر الواردة في العرض التجريبي.', submitted: '٢٣ سبتمبر · ١١:٠٠ ص', owner: 'محلل الأبحاث', ownerInitials: 'RA', ownerTone: 'blue', reference: 'NV-016', tone: 'blue' },
  ],
};

// Future API implementations can satisfy this interface without changing the UI.
export interface DashboardDataProvider {
  getDashboard(): Promise<DashboardSnapshot>;
}

export const demoDataProvider: DashboardDataProvider = {
  async getDashboard() {
    return demoSnapshot;
  },
};