import { useMemo, useState } from 'react';
import {
  Activity,
  AlertOctagon,
  ArrowDownLeft,
  Check,
  ClipboardCheck,
  Database,
  Eye,
  FileWarning,
  GitBranch,
  KeyRound,
  Layers3,
  LockKeyhole,
  Network,
  Play,
  RotateCcw,
  Search,
  ServerCog,
  ShieldAlert,
  ShieldCheck,
  Siren,
  Sparkles,
  Target,
  Users,
  Wrench,
  X,
} from 'lucide-react';
import {
  platformIntegrationLayers,
  platformSystemCatalog,
  sandboxChecks,
  type SystemDefinition,
} from '../platformSystems';
import type { SurfaceState } from '../modularData';

type PlatformControlCenterProps = { onNotice: (message: string) => void };

const stateLabel: Record<SurfaceState, string> = {
  Designed: 'مصمم',
  Simulated: 'تجريبي',
  Live: 'متصل فعلياً',
  Blocked: 'محجوب حتى الموافقة',
};

function StatusPill({ state }: { state: SurfaceState }) {
  return <span className={`mod-status mod-status-${state.toLowerCase()}`}><span />{stateLabel[state]}</span>;
}

function SystemIcon({ id }: { id: string }) {
  if (id.includes('goal') || id.includes('kpi')) return <Target size={16} />;
  if (id.includes('client') || id.includes('requirements') || id.includes('change')) return <Users size={16} />;
  if (id.includes('memory')) return <Database size={16} />;
  if (id.includes('market')) return <Network size={16} />;
  if (id.includes('pricing')) return <Layers3 size={16} />;
  if (id.includes('performance')) return <Activity size={16} />;
  if (id.includes('emergency')) return <Siren size={16} />;
  if (id.includes('review')) return <ShieldCheck size={16} />;
  if (id.includes('sandbox') || id.includes('twin')) return <RotateCcw size={16} />;
  if (id.includes('tools') || id.includes('marketplace')) return <Wrench size={16} />;
  return <ServerCog size={16} />;
}

function SystemCard({ system, selected, onSelect }: { system: SystemDefinition; selected: boolean; onSelect: () => void }) {
  return (
    <button className={`platform-system-card ${selected ? 'platform-system-card-selected' : ''}`} onClick={onSelect} data-testid={`button-system-${system.id}`}>
      <div className="system-card-top"><span className="system-card-icon"><SystemIcon id={system.id} /></span><StatusPill state={system.state} /></div>
      <strong>{system.title}</strong>
      <span className="system-card-english">{system.english}</span>
      <span className="system-card-owner">{system.owner}</span>
      <div className="system-card-dashboard"><Activity size={11} /> {system.dashboard}</div>
      <div className="system-card-foot"><span>{system.metrics[0]?.label}: <b>{system.metrics[0]?.value}</b></span><ArrowDownLeft size={13} /></div>
    </button>
  );
}

function ResultIcon({ result }: { result: string }) {
  if (result === 'Passed') return <Check size={13} />;
  if (result === 'Review') return <FileWarning size={13} />;
  return <AlertOctagon size={13} />;
}

export function PlatformControlCenter({ onNotice }: PlatformControlCenterProps) {
  const [selectedId, setSelectedId] = useState(platformSystemCatalog[0].id);
  const [filter, setFilter] = useState<'all' | SurfaceState>('all');
  const [query, setQuery] = useState('');
  const [sandboxRun, setSandboxRun] = useState(false);
  const selectedSystem = platformSystemCatalog.find((system) => system.id === selectedId) ?? platformSystemCatalog[0];
  const visibleSystems = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase('ar');
    return platformSystemCatalog.filter((system) => {
      const matchesState = filter === 'all' || system.state === filter;
      const matchesQuery = !normalized || `${system.title} ${system.english} ${system.owner} ${system.mission}`.toLocaleLowerCase('ar').includes(normalized);
      return matchesState && matchesQuery;
    });
  }, [filter, query]);

  const runSandbox = () => {
    setSandboxRun(true);
    onNotice('تم تشغيل اختبار تكامل Sandbox ببيانات ثابتة فقط. لم يتم تنفيذ اتصال أو تغيير حي.');
    window.setTimeout(() => setSandboxRun(false), 5000);
  };

  return (
    <section id="systems" className="section-block section-anchor modular-section platform-control-section">
      <div className="section-header">
        <div className="section-heading-content"><span className="section-eyebrow"><span>13</span>عقل المنصة والحوكمة</span><h2>Platform Control Center</h2><p>لوحات مستقلة للأهداف والذاكرة والعملاء والتجارب والأمان والاستعادة، فوق بنية المجالات والـ131 Agent.</p></div>
        <div className="section-header-action"><span className="count-chip"><ServerCog size={13} /> {platformSystemCatalog.length} أنظمة</span></div>
      </div>

      <div className="platform-hero">
        <div className="platform-hero-mark"><Sparkles size={21} /></div>
        <div><strong>Nova Vision Operating Layer</strong><p>Designed / Simulated فقط حالياً. لا خدمات خارجية، لا دفع، لا مفاتيح API، ولا تشغيل Agents في الخلفية.</p></div>
        <div className="platform-hero-actions"><button className="button button-outline" onClick={runSandbox}><Play size={13} /> {sandboxRun ? 'الاختبار يعمل…' : 'تشغيل Sandbox Test'}</button><button className="button button-outline" onClick={() => onNotice('Emergency Operations Mode مصمم للمالك فقط؛ لم يتم إيقاف أي شيء حي.') }><Siren size={13} /> Emergency Mode</button></div>
      </div>

      <div className="platform-command-flow">
        <div><span className="command-flow-icon"><Target size={15} /></span><b>Goals</b><small>هدف المالك</small></div><ArrowDownLeft size={14} /><div><span className="command-flow-icon"><Network size={15} /></span><b>Decision Engine</b><small>تفكيك وتوزيع</small></div><ArrowDownLeft size={14} /><div><span className="command-flow-icon"><Users size={15} /></span><b>19 Domains</b><small>Manager + Agents</small></div><ArrowDownLeft size={14} /><div><span className="command-flow-icon"><ShieldCheck size={15} /></span><b>QA + Nova Eye</b><small>مراجعة واستقلال</small></div><ArrowDownLeft size={14} /><div><span className="command-flow-icon"><KeyRound size={15} /></span><b>Owner Approval</b><small>عند الحساسية</small></div>
      </div>

      <div className="platform-toolbar">
        <label className="platform-search"><Search size={15} /><input type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث عن نظام أو مالك أو وظيفة..." /></label>
        <div className="platform-filters">{(['all', 'Designed', 'Simulated', 'Live', 'Blocked'] as const).map((option) => <button key={option} className={filter === option ? 'platform-filter-active' : ''} onClick={() => setFilter(option)}>{option === 'all' ? 'كل الأنظمة' : stateLabel[option]}</button>)}</div>
      </div>

      <div className="platform-system-grid">
        {visibleSystems.map((system) => <SystemCard key={system.id} system={system} selected={system.id === selectedId} onSelect={() => setSelectedId(system.id)} />)}
      </div>

      <div className="platform-system-detail">
        <div className="platform-detail-head">
          <div className="platform-detail-title"><span className="platform-detail-icon"><SystemIcon id={selectedSystem.id} /></span><div><span className="section-kicker">{selectedSystem.dashboard}</span><h3>{selectedSystem.title}</h3><p>{selectedSystem.mission}</p></div></div>
          <div className="platform-detail-status"><StatusPill state={selectedSystem.state} /><span>Owner: {selectedSystem.owner}</span></div>
        </div>
        <div className="platform-detail-grid">
          <div className="platform-detail-main">
            <div className="platform-workflow"><span className="section-kicker">Workflow / نقطة التحكم</span><div>{selectedSystem.workflow.map((step, index) => <div className="platform-workflow-step" key={step}><span>{String(index + 1).padStart(2, '0')}</span><b>{step}</b>{index < selectedSystem.workflow.length - 1 && <i />}</div>)}</div></div>
            <div className="platform-metric-grid">{selectedSystem.metrics.map((metric) => <div className="platform-metric" key={metric.label}><span>{metric.label}</span><strong>{metric.value}</strong><small>{metric.detail}</small></div>)}</div>
            <div className="platform-contract-grid"><div><b>Scope</b><span>{selectedSystem.scope}</span></div><div><b>Inputs</b><span>{selectedSystem.inputs}</span></div><div><b>Outputs</b><span>{selectedSystem.outputs}</span></div><div><b>Guardrail</b><span>{selectedSystem.guardrail}</span></div></div>
          </div>
          <aside className="platform-detail-side">
            <div className="platform-side-block"><span className="section-kicker">سجل النظام</span>{selectedSystem.logs.map((log) => <div className="platform-log" key={`${log.time}-${log.text}`}><span className={`platform-log-dot log-${log.kind}`} /><div><small>{log.time}</small><span>{log.text}</span></div></div>)}</div>
            <div className="platform-side-block"><span className="section-kicker">Records / Dashboard</span>{selectedSystem.records.map((record) => <div className="platform-record" key={record.label}><span>{record.label}</span><b>{record.value}</b></div>)}</div>
            <div className="platform-side-block"><span className="section-kicker">الربط</span><div className="platform-layer-list">{selectedSystem.connectedLayers.map((layer) => <span key={layer}><Check size={11} />{layer}</span>)}</div></div>
          </aside>
        </div>
        <div className="platform-permission-strip"><div><ShieldCheck size={14} /><span><b>مسموح</b>{selectedSystem.allowed}</span></div><div><LockKeyhole size={14} /><span><b>محجوب</b>{selectedSystem.blocked}</span></div><button className="plain-icon" onClick={() => onNotice('أي طلب حساس يتجه إلى Review Board ثم Owner Approval؛ لم يتم تنفيذ إجراء.') } aria-label="عرض مسار الموافقة"><ArrowDownLeft size={15} /></button></div>
      </div>

      <div className="platform-section-title"><span className="section-kicker">Integration Map</span><h3>الأنظمة المرتبطة بالطبقات الحالية</h3><p>كل رابط وصفي داخل التصميم؛ لا يعني اتصالاً حياً أو صلاحية عبور بين المجالات.</p></div>
      <div className="platform-integration-grid">{platformIntegrationLayers.map((layer) => <article className="platform-integration-card" key={layer.label}><span className="integration-icon"><GitBranch size={14} /></span><div><b>{layer.label}</b><span>{layer.purpose}</span></div><StatusPill state={layer.state} /></article>)}</div>

      <div className="platform-section-title"><span className="section-kicker">Sandbox Assurance</span><h3>نتائج اختبار التكامل والحدود</h3><p>بيانات تجريبية ثابتة لا تمثل اختبار اختراق أو اتصالاً إنتاجياً.</p></div>
      <div className="sandbox-assurance-panel">
        <div className="sandbox-assurance-summary"><div className="sandbox-ring"><strong>27<small>/30</small></strong><span>اختبارات ناجحة</span></div><div><b>{sandboxRun ? 'الاختبار جارٍ في Sandbox' : 'آخر تشغيل: بيانات ثابتة'}</b><p>لا تسرب بين العملاء أو المجالات في Fixtures. التحذيرات موقوفة للمراجعة ولا تسمح بالنشر.</p><button className="button button-outline" onClick={runSandbox}><ClipboardCheck size={13} /> إعادة تشغيل الاختبارات</button></div></div>
        <div className="sandbox-check-list">{sandboxChecks.map((check) => <div className={`sandbox-check sandbox-${check.result.toLowerCase()}`} key={check.label}><span className="sandbox-check-icon"><ResultIcon result={check.result} /></span><div><b>{check.label}</b><small>{check.detail}</small></div><span className="sandbox-result">{check.result === 'Passed' ? 'Passed' : 'Review'}</span></div>)}</div>
      </div>

      <div className="platform-safety-footer"><div><Eye size={15} /><span><b>Nova Eye</b><small>مراقبة مستقلة للتعارض والصلاحيات</small></span></div><div><ShieldAlert size={15} /><span><b>Guard Commander</b><small>دفاع وإيقاف ومراجعة مزدوجة</small></span></div><div><Database size={15} /><span><b>Backups / DR</b><small>Snapshots وKnown-good وRollback</small></span></div><div><AlertOctagon size={15} /><span><b>Owner Boundary</b><small>القرارات الحساسة لا تنفذ تلقائياً</small></span></div></div>
    </section>
  );
}