import { useMemo, useState } from 'react';
import {
  Activity,
  AlertOctagon,
  ArrowDownLeft,
  Bot,
  Boxes,
  Check,
  ChevronLeft,
  ClipboardCheck,
  Database,
  DatabaseBackup,
  Eye,
  FileLock2,
  FolderLock,
  GitBranch,
  KeyRound,
  Layers3,
  LockKeyhole,
  Network,
  Plus,
  RotateCcw,
  Search,
  ServerCog,
  ShieldAlert,
  ShieldCheck,
  Siren,
  UserRound,
  Wrench,
  X,
} from 'lucide-react';
import {
  agentMap,
  domainDefinitions,
  platformModules,
  totalAgentCount,
  type AgentDefinition,
  type DomainDefinition,
  type SurfaceState,
} from '../modularData';

type DomainOperatingSystemProps = { onNotice: (message: string) => void };

const statusLabel: Record<SurfaceState, string> = {
  Designed: 'مصمم',
  Simulated: 'تجريبي',
  Live: 'متصل فعلياً',
  Blocked: 'محجوب حتى الموافقة',
};

function StatusPill({ state }: { state: SurfaceState }) {
  return <span className={`mod-status mod-status-${state.toLowerCase()}`}><span />{statusLabel[state]}</span>;
}

function DomainCard({ domain, selected, onSelect }: { domain: DomainDefinition; selected: boolean; onSelect: () => void }) {
  return (
    <button className={`domain-card domain-card-${domain.tone} ${selected ? 'domain-card-selected' : ''}`} onClick={onSelect} data-testid={`button-domain-${domain.id}`}>
      <div className="domain-card-top"><span className="domain-glyph"><Boxes size={17} /></span><StatusPill state={domain.state} /></div>
      <strong>{domain.name}</strong>
      <span className="domain-english">{domain.english}</span>
      <div className="domain-manager"><span className="domain-manager-avatar">{domain.manager.slice(0, 1)}</span><span>{domain.manager}</span><ChevronLeft size={13} /></div>
      <div className="domain-card-foot"><span><Bot size={12} /> {domain.agents.length} Agents</span><span><LockKeyhole size={12} /> معزول</span></div>
    </button>
  );
}

function DetailRow({ icon: Icon, title, detail }: { icon: typeof Database; title: string; detail: string }) {
  return <div className="domain-detail-row"><div className="domain-detail-icon"><Icon size={14} /></div><div><strong>{title}</strong><span>{detail}</span></div><Check size={14} /></div>;
}

function AgentMapRow({ domain, agent, onSelect }: { domain: DomainDefinition; agent: AgentDefinition; onSelect: () => void }) {
  return (
    <button className="agent-map-row" onClick={onSelect} data-testid={`button-agent-${agent.id}`}>
      <span className="agent-map-domain"><i className={`agent-domain-dot dot-${domain.tone}`} />{domain.name}</span>
      <span className="agent-map-manager">{domain.manager}</span>
      <span className="agent-map-agent"><b>{agent.name}</b><small>{agent.role}</small></span>
      <span className="agent-map-command">{agent.mission}</span>
      <StatusPill state={agent.state} />
      <span className="agent-map-tools">{agent.tools.join(' · ')}</span>
      <span className="agent-map-permissions"><b>يسمح:</b> {agent.allowed}<em>يمنع: {agent.denied}</em></span>
      <span className="agent-map-task"><b>{agent.taskLog.lastTask}</b><small>{agent.taskLog.lastResult}</small></span>
      <span className="agent-map-test">{agent.latestTest}</span>
      <span className="agent-map-error">{agent.taskLog.lastError}</span>
      <span className="agent-map-failover"><b>{agent.failover.tier}</b><small>{agent.failover.standby} · {agent.failover.coldBackup}</small></span>
      <span className="agent-map-version"><b>{agent.currentVersion}</b><small>{agent.failover.checkpoint}</small></span>
    </button>
  );
}

function AgentInspectPanel({ agent, domain, onClose }: { agent: AgentDefinition; domain: DomainDefinition; onClose: () => void }) {
  return (
    <div className="agent-inspect-panel">
      <div className="agent-inspect-head">
        <div className="agent-inspect-title"><span className="agent-inspect-icon"><Bot size={18} /></span><div><span className="section-kicker">Agent Specification · {domain.name}</span><h3>{agent.name}</h3><p>{agent.role} · يراجعه {agent.reviewer} ويصعّد إلى {agent.escalation}</p></div></div>
        <button className="plain-icon" onClick={onClose} aria-label="إغلاق مواصفات الوكيل"><X size={17} /></button>
      </div>
      <div className="agent-spec-grid">
        <div><b>الأمر الداخلي</b><pre>{agent.prompt}</pre></div>
        <div className="agent-spec-list">
          <div><b>المدخلات</b><span>{agent.inputs}</span></div>
          <div><b>المخرجات</b><span>{agent.outputs}</span></div>
          <div><b>البيانات</b><span>{agent.dataAccess}</span></div>
          <div><b>بوابة الجودة</b><span>{agent.qualityGate}</span></div>
          <div><b>المهام والنتيجة</b><span>{agent.taskLog.lastTask} · {agent.taskLog.lastResult}</span></div>
          <div><b>آخر اختبار/خطأ</b><span>{agent.latestTest} · {agent.taskLog.lastError}</span></div>
          <div><b>Failover</b><span>{agent.failover.tier} · {agent.failover.standby} · {agent.failover.coldBackup}</span></div>
        </div>
      </div>
    </div>
  );
}

export function DomainOperatingSystem({ onNotice }: DomainOperatingSystemProps) {
  const [selectedId, setSelectedId] = useState(domainDefinitions[0].id);
  const [filter, setFilter] = useState<'all' | SurfaceState>('all');
  const [workspaceOpen, setWorkspaceOpen] = useState(false);
  const [agentQuery, setAgentQuery] = useState('');
  const [agentDomainFilter, setAgentDomainFilter] = useState('all');
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const selectedDomain = domainDefinitions.find((domain) => domain.id === selectedId) ?? domainDefinitions[0];
  const visibleDomains = useMemo(() => filter === 'all' ? domainDefinitions : domainDefinitions.filter((domain) => domain.state === filter), [filter]);
  const visibleAgents = useMemo(() => {
    const query = agentQuery.trim().toLocaleLowerCase('ar');
    return agentMap.filter(({ domain, agent }) => {
      const matchesDomain = agentDomainFilter === 'all' || domain.id === agentDomainFilter;
      const searchable = `${domain.name} ${domain.manager} ${agent.name} ${agent.role} ${agent.mission}`.toLocaleLowerCase('ar');
      return matchesDomain && (!query || searchable.includes(query));
    });
  }, [agentDomainFilter, agentQuery]);
  const selectedAgentRecord = selectedAgentId ? agentMap.find(({ agent }) => agent.id === selectedAgentId) : undefined;

  return (
    <>
      <section id="domains" className="section-block section-anchor modular-section">
        <div className="section-header">
          <div className="section-heading-content"><span className="section-eyebrow"><span>08</span>نظام التشغيل المعياري</span><h2>كل مجال، مساحة مستقلة</h2><p>19 Domain بحسابات منطقية منفصلة، ومدير وQA وAgents وذاكرة وصلاحيات خاصة.</p></div>
          <div className="section-header-action"><span className="count-chip"><Network size={13} /> {domainDefinitions.length} مجالات · {totalAgentCount} Agents</span></div>
        </div>

        <div className="modular-banner">
          <div className="modular-banner-icon"><Network size={20} /></div>
          <div><strong>Nova Vision → General Manager → Domain Manager → Agents → QA → Approvals → Reports</strong><p>التنسيق المركزي يمر عبر Request مسجل؛ لا يوجد وصول مباشر من مجال إلى Agent أو بيانات مجال آخر.</p></div>
          <StatusPill state="Designed" />
        </div>

        <div className="domain-boundary-strip">
          <div><FolderLock size={15} /><span>عزل مساحة العميل</span><b>مفعل في التصميم</b></div>
          <div><FileLock2 size={15} /><span>تصنيف البيانات والاحتفاظ</span><b>محدد لكل مجال</b></div>
          <div><GitBranch size={15} /><span>واجهات التكامل</span><b>عبر طلبات رسمية</b></div>
          <div><ShieldCheck size={15} /><span>بوابات الجودة</span><b>مراجعة بشرية للمخاطر</b></div>
        </div>

        <div className="domain-toolbar">
          <div className="domain-filters">
            {(['all', 'Designed', 'Simulated', 'Blocked'] as const).map((option) => <button key={option} className={filter === option ? 'domain-filter-active' : ''} onClick={() => setFilter(option)}>{option === 'all' ? 'كل المجالات' : statusLabel[option]}</button>)}
          </div>
          <span className="mod-microcopy">بيانات Demo · لا توجد اتصالات خارجية مفعّلة</span>
        </div>

        <div className="domain-grid">
          {visibleDomains.map((domain) => <DomainCard key={domain.id} domain={domain} selected={domain.id === selectedId} onSelect={() => setSelectedId(domain.id)} />)}
        </div>

        <div className="domain-detail-panel">
          <div className="domain-detail-heading">
            <div><span className="section-kicker">مساحة المجال المحدد · {selectedDomain.workspace.accountName}</span><h3>{selectedDomain.name}</h3><p>{selectedDomain.english} · كل البيانات التالية تجريبية ومفصولة منطقياً عن المجالات الأخرى.</p></div>
            <button className="button button-primary" onClick={() => setWorkspaceOpen((open) => !open)}>{workspaceOpen ? <X size={15} /> : <ArrowDownLeft size={15} />}{workspaceOpen ? 'إغلاق التفاصيل' : 'فتح مساحة المجال'}</button>
          </div>
          <div className="domain-detail-grid">
            <DetailRow icon={Network} title="المدير والمنسق" detail={`${selectedDomain.manager} · نقطة التنسيق الوحيدة`} />
            <DetailRow icon={UserRound} title="Domain QA" detail={`${selectedDomain.qa} · بوابة ما قبل التسليم`} />
            <DetailRow icon={Bot} title="الوكلاء المتخصصون" detail={`${selectedDomain.agents.length} Agent · لكل واحد Prompt ونطاق`} />
            <DetailRow icon={Database} title="Knowledge Base" detail={selectedDomain.workspace.knowledgeBase} />
            <DetailRow icon={Layers3} title="Task Queue" detail={selectedDomain.queue} />
            <DetailRow icon={Wrench} title="Tool Registry" detail={selectedDomain.tools.join(' · ')} />
            <DetailRow icon={FolderLock} title="Projects / Clients" detail={selectedDomain.workspace.projectsClients} />
            <DetailRow icon={ClipboardCheck} title="Approval Queue" detail={selectedDomain.workspace.approvalQueue} />
            <DetailRow icon={ShieldCheck} title="صلاحيات المجال" detail={selectedDomain.workspace.permissions} />
          </div>
          {workspaceOpen && (
            <div className="domain-workspace">
              <div className="workspace-tab-row"><span className="workspace-tab-active">لوحة المجال</span><span>Agents ({selectedDomain.agents.length})</span><span>المهام</span><span>الأدوات</span><span>الملفات والمعرفة</span><span>QA</span><span>Audit Log</span><span>التقارير</span></div>
              <div className="workspace-account-grid">
                <div><Database size={15} /><b>ملفات وبيانات</b><span>{selectedDomain.workspace.filesData}</span></div>
                <div><GitBranch size={15} /><b>Interface</b><span>{selectedDomain.interface}</span></div>
                <div><Activity size={15} /><b>Dashboard</b><span>{selectedDomain.workspace.dashboard}</span></div>
                <div><ClipboardCheck size={15} /><b>Audit Log</b><span>{selectedDomain.workspace.auditLog}</span></div>
              </div>
              <div className="workspace-empty"><div className="workspace-empty-icon"><Database size={20} /></div><strong>هذه مساحة Demo معزولة</strong><p>لا توجد ملفات عملاء أو مصادر خارجية متصلة. أي طلب من مجال آخر يمر عبر واجهة: <b>{selectedDomain.interface}</b></p><button className="button button-outline" onClick={() => onNotice('طلب الربط بين المجالات لا ينفذ تلقائياً؛ يحتاج عقداً ونطاقاً وموافقة حسب الحساسية.')}>محاكاة طلب تكامل رسمي <ArrowDownLeft size={14} /></button></div>
            </div>
          )}
        </div>
      </section>

      <section id="agent-map" className="section-block section-anchor modular-section">
        <div className="section-header">
          <div className="section-heading-content"><span className="section-eyebrow"><span>09</span>الهيكل التنفيذي</span><h2>خريطة الـ131 Agent</h2><p>سجل مواصفات قابل للتنفيذ لاحقاً؛ كل Agent له نطاق، Prompt داخلي، أدوات، صلاحيات، QA وFailover.</p></div>
          <div className="section-header-action"><span className="count-chip"><Bot size={13} /> {visibleAgents.length} / {totalAgentCount}</span></div>
        </div>
        <div className="agent-map-banner"><div className="agent-map-banner-icon"><ServerCog size={19} /></div><div><strong>Designed / Simulated وليست Agents تعمل في الخلفية</strong><p>هذه مواصفات وحسابات منطقية داخل Nova Vision. لا توجد خدمات خارجية أو مفاتيح أو تنفيذ مستقل حتى يتم تفعيل البنية الحية لاحقاً.</p></div><StatusPill state="Designed" /></div>
        <div className="agent-map-toolbar">
          <label className="agent-search"><Search size={15} /><input type="search" value={agentQuery} onChange={(event) => setAgentQuery(event.target.value)} placeholder="ابحث بالوكيل أو التخصص أو الأمر..." /></label>
          <select value={agentDomainFilter} onChange={(event) => setAgentDomainFilter(event.target.value)} aria-label="تصفية خريطة الوكلاء"><option value="all">كل المجالات · {totalAgentCount}</option>{domainDefinitions.map((domain) => <option key={domain.id} value={domain.id}>{domain.name} · {domain.agents.length}</option>)}</select>
          <span className="agent-map-count">11 حقلاً تشغيلياً لكل سجل</span>
        </div>
        <div className="agent-map-legend"><span><span className="legend-dot dot-primary" /> Primary</span><span><span className="legend-dot dot-standby" /> Standby</span><span><span className="legend-dot dot-cold" /> Cold Backup</span><span><span className="legend-dot dot-blocked" /> صلاحية محجوبة</span></div>
        <div className="agent-map-table">
          <div className="agent-map-head"><span>Domain</span><span>Manager</span><span>Agent / التخصص</span><span>الأمر الأساسي</span><span>الحالة</span><span>الأدوات</span><span>الصلاحيات</span><span>آخر مهمة / نتيجة</span><span>آخر اختبار</span><span>آخر خطأ</span><span>Primary / Standby</span><span>الإصدار</span></div>
          {visibleAgents.map(({ domain, agent }) => <AgentMapRow key={agent.id} domain={domain} agent={agent} onSelect={() => setSelectedAgentId(agent.id)} />)}
          {visibleAgents.length === 0 && <div className="empty-state">لا توجد Agents تطابق البحث أو المجال المحدد.</div>}
        </div>
        {selectedAgentRecord && <AgentInspectPanel agent={selectedAgentRecord.agent} domain={selectedAgentRecord.domain} onClose={() => setSelectedAgentId(null)} />}
      </section>

      <section id="accounts" className="section-block section-anchor modular-section">
        <div className="section-header">
          <div className="section-heading-content"><span className="section-eyebrow"><span>10</span>الحسابات المنطقية</span><h2>حسابات المجالات</h2><p>كل Domain يملك Workspace منطقي مستقل داخل Nova Workspace، وليس حساب بريد أو خدمة خارجية.</p></div>
          <div className="section-header-action"><span className="count-chip"><FolderLock size={13} /> {domainDefinitions.length} Workspaces</span></div>
        </div>
        <div className="account-disclaimer"><LockKeyhole size={16} /><span><strong>العزل في التصميم فقط حالياً.</strong> لا يتم إنشاء حسابات خارجية ولا تخزين كلمات مرور أو مفاتيح API. التحويل إلى عزل فعلي يحتاج API وقاعدة بيانات وصلاحيات خادمية.</span><StatusPill state="Simulated" /></div>
        <div className="domain-account-grid">
          {domainDefinitions.map((domain) => (
            <article className={`domain-account-card account-${domain.tone}`} key={domain.id}>
              <div className="account-card-top"><span className="account-glyph"><FolderLock size={16} /></span><StatusPill state={domain.state} /></div>
              <h3>{domain.workspace.accountName}</h3><p>{domain.english}</p>
              <div className="account-owner"><span className="domain-manager-avatar">{domain.manager.slice(0, 1)}</span><span><b>{domain.manager}</b><small>QA: {domain.qa}</small></span></div>
              <div className="account-stats"><span><b>{domain.agents.length}</b> Agents</span><span><b>{domain.tools.length}</b> Tools</span><span><b>1</b> Queue</span><span><b>1</b> Audit</span></div>
              <div className="account-fields"><span><Database size={12} /> {domain.workspace.knowledgeBase}</span><span><FolderLock size={12} /> {domain.workspace.projectsClients}</span><span><ClipboardCheck size={12} /> Approval منفصلة</span></div>
              <button className="account-open" onClick={() => { setSelectedId(domain.id); document.getElementById('domains')?.scrollIntoView({ behavior: 'smooth' }); }}>فتح مساحة المجال <ArrowDownLeft size={13} /></button>
            </article>
          ))}
        </div>
      </section>

      <section id="studio" className="section-block section-anchor modular-section">
        <div className="section-header">
          <div className="section-heading-content"><span className="section-eyebrow"><span>11</span>الأدوات الداخلية</span><h2>Nova Studio / Tools Factory</h2><p>منصة لبناء أدوات Nova واختبارها وإصدارها بنطاق وصلاحيات محددة.</p></div>
          <div className="section-header-action"><StatusPill state="Designed" /></div>
        </div>
        <div className="studio-panel">
          <div className="studio-intro"><div className="studio-icon"><Wrench size={21} /></div><div><strong>لا وصول شامل للأداة الجديدة</strong><p>كل أداة تحدد المجال، البيانات، الوكلاء، الإصدار، الاختبارات، والمراجعة الأمنية قبل إضافتها إلى Tool Registry.</p></div><button className="button button-outline" onClick={() => onNotice('إنشاء أداة جديدة محجوب في العرض التجريبي حتى يحدد المالك المجال والصلاحيات.')}><Plus size={14} /> أداة جديدة</button></div>
          <div className="studio-cards"><div><span className="studio-card-icon"><GitBranch size={15} /></span><strong>Versioning & Rollback</strong><span>إصدار معروف وسليم مع رجوع قابل للتراجع</span></div><div><span className="studio-card-icon"><ShieldCheck size={15} /></span><strong>Security Review</strong><span>مراجعة ثانية قبل إتاحة الأداة لأي Agent</span></div><div><span className="studio-card-icon"><Boxes size={15} /></span><strong>Sandbox & Regression</strong><span>اختبار معزول قبل النشر داخل المجال</span></div></div>
        </div>
      </section>

      <section id="boundaries" className="section-block section-anchor modular-section">
        <div className="section-header">
          <div className="section-heading-content"><span className="section-eyebrow"><span>12</span>حدود التنسيق والاستعادة</span><h2>Central Coordination & Recovery</h2><p>طبقة تنسيق ومراقبة وأمن واستعادة تربط المجالات دون دمج ذاكرتها أو صلاحياتها.</p></div>
          <div className="section-header-action"><StatusPill state="Simulated" /></div>
        </div>
        <div className="coordination-panel">
          <div className="coordination-flow"><div className="coord-node coord-owner"><span>المالك</span><small>السلطة النهائية</small></div><div className="coord-arrow"><ArrowDownLeft size={15} /></div><div className="coord-node"><span>General Manager</span><small>يوجه عبر Interface</small></div><div className="coord-arrow"><ArrowDownLeft size={15} /></div><div className="coord-node"><span>Domain Manager</span><small>ينسق داخل مجاله</small></div><div className="coord-arrow"><ArrowDownLeft size={15} /></div><div className="coord-node coord-domain"><span>Domain Agents</span><small>أقل صلاحية + Sandbox</small></div></div>
          <div className="coord-rules"><div><LockKeyhole size={15} /><span>لا خلط لبيانات العملاء أو الملفات أو المفاتيح</span></div><div><FileLock2 size={15} /><span>كل طلب عبر Interface: مصدر، سبب، نطاق، مدة</span></div><div><ShieldCheck size={15} /><span>QA يراجع قبل التسليم والتعارض يصعد للمالك</span></div><div><GitBranch size={15} /><span>كل قرار ومخرج يظهر في Audit Log موحد ومجالّي</span></div></div>
          <div className="platform-module-grid">{platformModules.map((module) => <div className="platform-module" key={module.label}><span className="platform-module-icon">{module.label.includes('Security') ? <ShieldAlert size={14} /> : module.label.includes('Recovery') ? <RotateCcw size={14} /> : module.label.includes('Eye') ? <Eye size={14} /> : module.label.includes('Secrets') ? <KeyRound size={14} /> : module.label.includes('Stop') ? <Siren size={14} /> : module.label.includes('Regression') ? <ClipboardCheck size={14} /> : <ServerCog size={14} />}</span><b>{module.label}</b><StatusPill state={module.state as SurfaceState} /><span>{module.detail}</span></div>)}</div>
          <div className="recovery-strip"><div><DatabaseBackup size={16} /><span><b>Disaster Recovery</b><small>Checkpoints وKnown-good Versions لكل Agent</small></span></div><div><AlertOctagon size={16} /><span><b>Emergency Stop</b><small>إيقاف مجال أو Agent دون حذف السجل</small></span></div><div><ShieldCheck size={16} /><span><b>Day of Reckoning</b><small>Recovery Drills لاختبار الحدود والتداخل</small></span></div></div>
        </div>
      </section>
    </>
  );
}