import { useState } from 'react';
import { LogOut, ShieldCheck } from 'lucide-react';
import { useOwnerAuth } from '@/lib/auth-context';

export function OwnerAuthControl() {
  const auth = useOwnerAuth();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');

  if (!auth.configured) {
    return (
      <span className="owner-auth-status" role="status">
        <ShieldCheck size={14} />
        {auth.available ? 'دخول المالك غير مهيأ · Demo' : 'الخادم غير متاح · Demo'}
      </span>
    );
  }

  if (!auth.authenticated) return null;

  async function handleSignOut() {
    setPending(true);
    setError('');
    try {
      await auth.signOut();
    } catch {
      setError('تعذر إنهاء الجلسة.');
    } finally {
      setPending(false);
    }
  }

  return (
    <span className="owner-auth-control">
      {error && <span className="owner-auth-inline-error" role="alert">{error}</span>}
      <button className="owner-auth-signed-in" type="button" onClick={handleSignOut} disabled={pending}>
        <LogOut size={14} />
        {pending ? 'جارٍ الخروج…' : 'خروج المالك · Sign out'}
      </button>
    </span>
  );
}
