import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  Activity,
  AlertTriangle,
  ArrowDownLeft,
  Bot,
  BrainCircuit,
  BriefcaseBusiness,
  Building2,
  Check,
  CheckCheck,
  ChevronDown,
  CircleCheck,
  CircleDot,
  Clock3,
  Compass,
  FileSearch,
  Flag,
  Gauge,
  Layers3,
  LayoutDashboard,
  ListTodo,
  Menu,
  MoreHorizontal,
  Network,
  LockKeyhole,
  Search,
    ServerCog, 
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp,
  Users,
  Wrench,
  X,
  Zap,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import {
  demoDataProvider,
  type ApprovalDecision,
  type DashboardSnapshot,
  type OpportunityStage,
  type TaskStatus,
} from './demoData';
import { DomainOperatingSystem } from './components/domain-operating-system';
import { PlatformControlCenter } from './components/platform-control-center';
import { OwnerAuthControl } from './components/owner-auth-control';
import { OwnerAuthProvider, OwnerSignInScreen, useOwnerAuth } from './lib/auth-context';

const queryClient = new QueryClient();

const navItems = [
  { id: 'overview', title: 'نظرة عامة', icon: LayoutDashboard },
  { id: 'mission', title: 'الرؤية والرسالة', icon: Compass },
  { id: 'agents', title: 'معمارية الوكلاء', icon: BrainCircuit },
  { id: 'opportunities', title: 'مسار الفرص', icon: TrendingUp },
  { id: 'research', title: 'قائمة الأبحاث', icon: FileSearch },
  { id: 'validation', title: 'التحقق', icon: ShieldCheck },
  { id: 'tasks', title: 'المهام', icon: ListTodo },
  { id: 'approvals', title: 'موافقات الرئيس التنفيذي', icon: CheckCheck },
  { id: 'domains', title: 'مجالات الأعمال', icon: Network },
  { id: 'agent-map', title: 'خريطة الـ131 Agent', icon: Bot },
  { id: 'accounts', title: 'حسابات المجالات', icon: Building2 },
  { id: 'studio', title: 'Nova Studio', icon: Wrench },
  { id: 'boundaries', title: 'حدود التنسيق', icon: LockKeyhole },
  { id: 'systems', title: 'أنظمة المنصة', icon: ServerCog },
] as const;

type LocalState = {
  taskStatus: Record<string, TaskStatus>;
  approvalDecisions: Record<string, ApprovalDecision>;
  opportunityStages: Record<string, OpportunityStage>;
};

const LOCAL_STATE_KEY = 'nova-vision-demo-controls-v1';

function getSavedLocalState(): LocalState {
  const empty: LocalState = {
    taskStatus: {},
    approvalDecisions: {},
    opportunityStages: {},
  };
  try {
    const saved = window.localStorage.getItem(LOCAL_STATE_KEY);
    return saved ? { ...empty, ...JSON.parse(saved) } : empty;
  } catch {
    return empty;
  }
}

function Home() {
  const auth = useOwnerAuth();
  const [snapshot, setSnapshot] = useState<DashboardSnapshot | null>(null);
  const [localState, setLocalState] = useState<LocalState>(getSavedLocalState);
  const [activeSection, setActiveSection] = useState<string>('overview');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const [stageFilter, setStageFilter] = useState<OpportunityStage | 'all'>('all');
  const [notice, setNotice] = useState('');
  const [taskMode, setTaskMode] = useState<'demo' | 'loading' | 'saved' | 'error'>('demo');
  const [taskTitle, setTaskTitle] = useState('');
  const [taskProject, setTaskProject] = useState('');
  const [taskDue, setTaskDue] = useState('');
  const [taskPriority, setTaskPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [taskSaving, setTaskSaving] = useState(false);

  useEffect(() => {
    let active = true;
    void (async () => {
      const baseSnapshot = await demoDataProvider.getDashboard();
      if (!active) return;
      if (!auth.authenticated) {
        setSnapshot(baseSnapshot);
        setTaskMode('demo');
        return;
      }

      setSnapshot({ ...baseSnapshot, tasks: [] });
      setTaskMode('loading');
      try {
        const response = await fetch('/api/tasks', { credentials: 'same-origin', cache: 'no-store' });
        if (!response.ok) throw new Error('TASKS_UNAVAILABLE');
        const result = await response.json();
        if (!Array.isArray(result.tasks)) throw new Error('INVALID_TASK_RESPONSE');
        if (active) {
          setSnapshot({ ...baseSnapshot, tasks: result.tasks });
          setTaskMode('saved');
        }
      } catch {
        if (active) {
          setTaskMode('error');
          setNotice('تعذر تحميل المهام المحفوظة. لم نعرض بيانات تجريبية على أنها بيانات فعلية.');
        }
      }
    })();
    return () => {
      active = false;
    };
  }, [auth.authenticated]);

  useEffect(() => {
    try {
      window.localStorage.setItem(LOCAL_STATE_KEY, JSON.stringify(localState));
    } catch {
      // Local storage is optional; the demo remains usable in this session.
    }
  }, [localState]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActiveSection(visible.target.id);
      },
      { rootMargin: '-22% 0px -62% 0px', threshold: [0, 0.2, 0.5] },
    );
    navItems.forEach(({ id }) => {
      const section = document.getElementById(id);
      if (section) observer.observe(section);
    });
    return () => observer.disconnect();
  }, [snapshot]);

  const setTaskStatus = async (id: string, status: TaskStatus) => {
    if (taskMode === 'saved' && auth.authenticated) {
      try {
        const response = await fetch(`/api/tasks/${encodeURIComponent(id)}`, {
          method: 'PATCH',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status }),
        });
        if (!response.ok) throw new Error('TASK_UPDATE_FAILED');
        const result = await response.json();
        setSnapshot((current) => current
          ? { ...current, tasks: current.tasks.map((task) => task.id === id ? result.task : task) }
          : current);
      } catch {
        setNotice('تعذر حفظ حالة المهمة على الخادم.');
        window.setTimeout(() => setNotice(''), 4200);
      }
      return;
    }
    setLocalState((current) => ({
      ...current,
      taskStatus: { ...current.taskStatus, [id]: status },
    }));
  };

  const createTask = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (taskMode !== 'saved' || !auth.authenticated || !taskTitle.trim() || taskSaving) return;
    setTaskSaving(true);
    try {
      const response = await fetch('/api/tasks', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: taskTitle.trim(),
          project: taskProject.trim(),
          due: taskDue,
          priority: taskPriority,
        }),
      });
      if (!response.ok) throw new Error('TASK_CREATE_FAILED');
      const result = await response.json();
      setSnapshot((current) => current
        ? { ...current, tasks: [...current.tasks, result.task] }
        : current);
      setTaskTitle('');
      setTaskProject('');
      setTaskDue('');
      setTaskPriority('medium');
    } catch {
      setNotice('تعذر حفظ المهمة. لم تُضف إلى قائمة العرض.');
      window.setTimeout(() => setNotice(''), 4200);
    } finally {
      setTaskSaving(false);
    }
  };

  const decideApproval = (id: string, decision: ApprovalDecision) => {
    setLocalState((current) => ({
      ...current,
      approvalDecisions: { ...current.approvalDecisions, [id]: decision },
    }));
    setNotice('تم تحديث حالة العرض محلياً فقط. لم يتم تنفيذ أي إجراء فعلي.');
    window.setTimeout(() => setNotice(''), 4200);
  };

  const updateStage = (id: string, stage: OpportunityStage) => {
    setLocalState((current) => ({
      ...current,
      opportunityStages: { ...current.opportunityStages, [id]: stage },
    }));
  };

  if (!snapshot) {
    return (
      <div className="loading-screen" dir="rtl" lang="ar">
        <div className="loading-mark"><Sparkles size={21} /></div>
        <p>جارٍ تجهيز لوحة العرض التجريبية…</p>
      </div>
    );
  }

  const query = searchValue.trim().toLocaleLowerCase('ar');
  const visibleOpportunities = snapshot.opportunities.filter((item) => {
    const stage = localState.opportunityStages[item.id] ?? item.stage;
    const matchesStage = stageFilter === 'all' || stage === stageFilter;
    const matchesQuery =
      !query ||
      `${item.title} ${item.sector} ${item.market}`.toLocaleLowerCase('ar').includes(query);
    return matchesStage && matchesQuery;
  });

  return (
    <div className="app-shell" dir="rtl" lang="ar">
      <aside className={`sidebar ${mobileNavOpen ? 'sidebar-open' : ''}`} aria-label="التنقل الرئيسي">
        <div className="brand">
          <div className="brand-symbol"><Sparkles size={19} strokeWidth={2.3} /></div>
          <div className="brand-copy">
            <span className="brand-name">NOVA <b>VISION</b></span>
            <span className="brand-caption">مركز القيادة</span>
          </div>
          <button className="icon-button sidebar-close" onClick={() => setMobileNavOpen(false)} aria-label="إغلاق القائمة">
            <X size={19} />
          </button>
        </div>

        <div className="workspace-switcher">
          <div className="workspace-icon"><BrainCircuit size={19} /></div>
          <div className="workspace-info">
            <strong>Nova Vision</strong>
            <span>مكتب الرئيس التنفيذي</span>
          </div>
          <ChevronDown size={15} className="workspace-chevron" />
        </div>

        <div className="nav-heading">مساحة العمل</div>
        <nav className="main-nav">
          {navItems.map(({ id, title, icon: Icon }) => {
            const isActive = activeSection === id;
            return (
              <a
                key={id}
                href={`#${id}`}
                className={`nav-link ${isActive ? 'active' : ''}`}
                aria-current={isActive ? 'location' : undefined}
                data-testid={`link-nav-${id}`}
                onClick={() => setMobileNavOpen(false)}
              >
                <Icon size={17} strokeWidth={1.9} />
                <span>{title}</span>
                {id === 'approvals' && (
                  <span className="nav-count">{snapshot.approvals.filter((item) => !localState.approvalDecisions[item.id]).length}</span>
                )}
              </a>
            );
          })}
        </nav>

        <div className="sidebar-spacer" />
        <div className="sidebar-agent-card">
          <div className="sidebar-agent-top">
            <span className="online-pulse" />
            <span>حالة المنظومة</span>
            <span className="agent-live">تجريبي</span>
          </div>
          <strong>البيئة جاهزة للعرض</strong>
          <div className="system-meter"><span /></div>
          <div className="system-meter-labels"><span>الجاهزية</span><b>92%</b></div>
        </div>
        <div className="sidebar-profile">
          <div className="profile-avatar">NV</div>
          <div className="profile-copy"><strong>الرئيس التنفيذي</strong><span>مساحة تجريبية</span></div>
          <MoreHorizontal size={19} className="profile-more" />
        </div>
      </aside>

      {mobileNavOpen && <button className="nav-backdrop" onClick={() => setMobileNavOpen(false)} aria-label="إغلاق القائمة" />}

      <main className="main-area">
        <header className="topbar">
          <div className="topbar-leading">
            <button className="icon-button mobile-menu" onClick={() => setMobileNavOpen(true)} aria-label="فتح القائمة">
              <Menu size={21} />
            </button>
            <div className="breadcrumbs"><span>Nova Vision</span><span className="crumb-divider">/</span><b>مركز القيادة</b></div>
          </div>
          <div className="topbar-actions">
            <div className="demo-indicator">
              <span className="demo-dot" />
              {taskMode === 'saved' ? 'المهام محفوظة · بقية الأقسام تجريبية' : 'وضع العرض التجريبي'}
            </div>
            <OwnerAuthControl />
            <button className="icon-button search-toggle" aria-label="البحث" onClick={() => document.getElementById('opportunity-search')?.focus()}>
              <Search size={18} />
            </button>
            <div className="topbar-date"><span>الخميس، ٢٤ سبتمبر ٢٠٢٦</span><Clock3 size={15} /></div>
            <div className="top-avatar">NV</div>
          </div>
        </header>

        <div className="content-wrap">
          <div className="demo-ribbon" data-testid="status-demo-banner">
            <div className="ribbon-icon"><Activity size={16} /></div>
            <div>
              <strong>{taskMode === 'saved' ? 'بيانات مختلطة' : 'بيئة تجريبية'}</strong>
              <span>{taskMode === 'saved'
                ? 'قائمة المهام محفوظة عبر الخادم؛ بقية المؤشرات والأقسام ما زالت بيانات توضيحية.'
                : 'البيانات والمؤشرات أمثلة توضيحية. تغييرات العرض تُحفظ محليًا في هذا المتصفح فقط.'}</span>
            </div>
            <span className="ribbon-tag">{taskMode === 'saved' ? 'TASKS SAVED · DEMO' : 'DEMO'}</span>
          </div>

          <section id="overview" className="section-anchor">
            <div className="welcome-row">
              <div>
                <div className="eyebrow"><span className="eyebrow-line" /> مركز القيادة التنفيذي</div>
                <h1>مرحباً بك في <span>Nova Vision</span></h1>
                <p className="welcome-subtitle">رؤية واحدة. وكلاء أذكياء. قرارات يقودها الإنسان.</p>
              </div>
              <div className="overview-actions">
                <span className="last-updated"><span className="online-pulse" /> تحديث العرض: الآن</span>
                <button className="button button-primary" onClick={() => document.getElementById('approvals')?.scrollIntoView({ behavior: 'smooth' })}>
                  <CheckCheck size={16} /> مراجعة الموافقات
                </button>
              </div>
            </div>

            <div className="hero-grid">
              <article className="mission-hero">
                <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
                <div className="hero-content">
                  <div className="hero-kicker"><Sparkles size={14} /> رؤيتنا</div>
                  <h2>نبني أعمالاً أذكى،<br /><span>بقيادة الإنسان.</span></h2>
                  <p>{snapshot.mission.short}</p>
                  <a href="#mission" className="hero-link">اكتشف رسالتنا <ArrowDownLeft size={15} /></a>
                </div>
                <div className="hero-visual" aria-hidden="true">
                  <div className="visual-ring ring-a" /><div className="visual-ring ring-b" />
                  <div className="visual-core"><Sparkles size={29} /></div>
                  <div className="visual-satellite sat-a"><Zap size={13} /></div>
                  <div className="visual-satellite sat-b"><BrainCircuit size={14} /></div>
                </div>
                <div className="hero-footnote"><span className="tiny-spark">✦</span> ذكاء اصطناعي مسؤول، بنمو مستدام</div>
              </article>
              <div className="overview-side">
                <article className="health-card">
                  <div className="card-title-row">
                    <div><span className="section-kicker">مؤشر المنظومة</span><h3>صحة التشغيل</h3></div>
                    <div className="health-icon"><Gauge size={18} /></div>
                  </div>
                  <div className="health-main"><strong>{snapshot.metrics.readiness}<small>%</small></strong><span className="health-change"><TrendingUp size={14} /> +٤٪</span></div>
                  <div className="health-progress"><span style={{ width: `${snapshot.metrics.readiness}%` }} /></div>
                  <div className="health-foot"><span>جاهزية الوكلاء</span><span>{snapshot.metrics.activeAgents} من {snapshot.metrics.totalAgents} نشط</span></div>
                </article>
                <article className="approval-summary">
                  <div className="summary-icon"><ShieldCheck size={18} /></div>
                  <div className="summary-copy"><span>تحتاج مراجعتك</span><strong>{snapshot.approvals.filter((item) => !localState.approvalDecisions[item.id]).length} موافقات</strong></div>
                  <button className="summary-arrow" onClick={() => document.getElementById('approvals')?.scrollIntoView({ behavior: 'smooth' })} aria-label="الانتقال إلى الموافقات"><ArrowDownLeft size={17} /></button>
                </article>
              </div>
            </div>

            <div className="metric-grid">
              <MetricCard icon={Target} title="فرص قيد التقييم" value={String(snapshot.metrics.opportunities)} foot="ضمن مسار الفرص" color="teal" trend="نشطة" />
              <MetricCard icon={FileSearch} title="أبحاث في الانتظار" value={String(snapshot.metrics.researchQueued)} foot="تنتظر المراجعة" color="violet" trend="أولوية عالية" />
              <MetricCard icon={CircleCheck} title="اجتياز التحقق" value={`${snapshot.metrics.validationsPassed}/${snapshot.metrics.validationsTotal}`} foot="فحوصات أساسية" color="green" trend="مستقر" />
              <MetricCard icon={ListTodo} title="مهام مفتوحة" value={String(snapshot.metrics.openTasks)} foot="لدى فرق العمل" color="amber" trend="هذا الأسبوع" />
            </div>
          </section>

          <section id="mission" className="section-block section-anchor">
            <SectionHeader eyebrow="الاتجاه الاستراتيجي" title="الرؤية والرسالة" description="الذكاء الاصطناعي يوسّع قدرتنا؛ والإنسان يحدد الاتجاه." number="01" />
            <div className="mission-grid">
              <article className="mission-card mission-primary">
                <div className="mission-card-head"><div className="mini-icon"><Compass size={17} /></div><span>الرؤية</span><span className="mini-label">إلى أين نتجه</span></div>
                <h3>أن نكون الشريك الذكي<br />لنمو الأعمال الطموحة.</h3>
                <p>{snapshot.mission.vision}</p>
                <div className="mission-decor">01</div>
              </article>
              <article className="mission-card mission-secondary">
                <div className="mission-card-head"><div className="mini-icon"><Flag size={17} /></div><span>الرسالة</span><span className="mini-label">كيف نصل</span></div>
                <h3>نحوّل الفرص إلى<br />خطوات مدروسة.</h3>
                <p>{snapshot.mission.statement}</p>
                <div className="mission-decor">02</div>
              </article>
              <article className="principles-card">
                <span className="section-kicker">مبادئنا</span><h3>كيف نعمل</h3>
                {snapshot.mission.principles.map((principle, index) => (
                  <div className="principle-row" key={principle}><span className="principle-number">0{index + 1}</span><span>{principle}</span><Check size={15} /></div>
                ))}
              </article>
            </div>
          </section>

          <DomainOperatingSystem onNotice={(message) => {
            setNotice(message);
            window.setTimeout(() => setNotice(''), 4200);
          }} />

          <section id="agents" className="section-block section-anchor">
            <SectionHeader eyebrow="بنية العمل" title="معمارية الوكلاء" description="وكلاء متخصصون يعملون ضمن مسارات واضحة وتحت إشراف بشري." number="02" action={<span className="count-chip"><span className="online-pulse" /> {snapshot.metrics.activeAgents} وكلاء نشطين</span>} />
            <div className="agents-panel">
              <div className="agents-topline">
                <div><span className="section-kicker">طبقات المنظومة</span><h3>من الرصد إلى القرار</h3></div>
                <span className="micro-copy">بيانات تجريبية · الأسماء والأدوار توضيحية</span>
              </div>
              <div className="agent-flow">
                {snapshot.agents.map((agent, index) => (
                  <div className="agent-flow-item" key={agent.id}>
                    <article className={`agent-card agent-${agent.tone}`}>
                      <div className="agent-card-top"><div className="agent-icon"><agent.Icon size={19} /></div><span className={`status-pill status-${agent.status}`}>{agent.statusLabel}</span></div>
                      <div className="agent-name">{agent.name}</div>
                      <div className="agent-role">{agent.role}</div>
                      <div className="agent-card-foot"><span>{agent.activity}</span><span className={`agent-status-dot ${agent.status}`} /></div>
                    </article>
                    {index < snapshot.agents.length - 1 && <div className="flow-connector"><span /><ArrowDownLeft size={13} /></div>}
                  </div>
                ))}
                <div className="agent-flow-item human-flow-item">
                  <div className="human-oversight">
                    <div className="human-icon"><Users size={18} /></div><div><strong>الإشراف البشري</strong><span>المراجعة والقرار النهائي</span></div>
                    <ShieldCheck size={16} className="human-shield" />
                  </div>
                </div>
              </div>
              <div className="agents-footnote"><ShieldCheck size={15} /> الوكلاء يقترحون ويحلّلون؛ الإنسان يراجع ويقرر.</div>
            </div>
          </section>

          <section id="opportunities" className="section-block section-anchor">
            <SectionHeader eyebrow="النمو القادم" title="مسار الفرص" description="فرص أولية مرتبة لتسهيل النقاش والتقييم، وليست توقعات مالية." number="03" action={<span className="pipeline-total">{visibleOpportunities.length} فرص</span>} />
            <div className="pipeline-toolbar">
              <div className="stage-filters" role="group" aria-label="تصفية حسب المرحلة">
                <button className={stageFilter === 'all' ? 'filter-active' : ''} onClick={() => setStageFilter('all')}>الكل <span>{snapshot.opportunities.length}</span></button>
                {snapshot.opportunityStages.map((stage) => <button key={stage.id} className={stageFilter === stage.id ? 'filter-active' : ''} onClick={() => setStageFilter(stage.id)}>{stage.label}</button>)}
              </div>
              <label className="search-field"><Search size={16} /><input id="opportunity-search" data-testid="input-opportunity-search" type="search" placeholder="ابحث عن فرصة أو قطاع..." value={searchValue} onChange={(event) => setSearchValue(event.target.value)} /><kbd>⌘ K</kbd></label>
            </div>
            <div className="opportunity-grid">
              {visibleOpportunities.map((opportunity) => {
                const stage = localState.opportunityStages[opportunity.id] ?? opportunity.stage;
                return (
                  <article className="opportunity-card" key={opportunity.id} data-testid={`card-opportunity-${opportunity.id}`}>
                    <div className="opportunity-top">
                      <span className={`sector-symbol sector-${opportunity.tone}`}>{opportunity.mark}</span>
                      <button className="plain-icon" aria-label={`خيارات ${opportunity.title}`}><MoreHorizontal size={18} /></button>
                    </div>
                    <div className="opportunity-sector">{opportunity.sector}</div>
                    <h3>{opportunity.title}</h3>
                    <p className="opportunity-location">{opportunity.market} <span>·</span> {opportunity.source}</p>
                    <div className="opportunity-meta">
                      <div className="score-block"><span>ملاءمة أولية</span><strong>{opportunity.fit}<small>%</small></strong></div>
                      <div className="fit-bar"><span style={{ width: `${opportunity.fit}%` }} /></div>
                    </div>
                    <div className="opportunity-bottom">
                      <span className={`stage-badge stage-${stage}`}>{snapshot.opportunityStages.find((item) => item.id === stage)?.label}</span>
                      <select aria-label={`تغيير مرحلة ${opportunity.title}`} value={stage} onChange={(event) => updateStage(opportunity.id, event.target.value as OpportunityStage)}>
                        {snapshot.opportunityStages.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
                      </select>
                    </div>
                  </article>
                );
              })}
              {visibleOpportunities.length === 0 && <div className="empty-state">لا توجد فرص تطابق البحث أو المرحلة المحددة.</div>}
            </div>
            <div className="data-note"><AlertTriangle size={14} /> درجات الملاءمة فرضيات تجريبية وليست توصية استثمارية.</div>
          </section>

          <section id="research" className="section-block section-anchor">
            <SectionHeader eyebrow="إشارات السوق" title="قائمة الأبحاث" description="مسارات بحث مقترحة تنتظر التحليل والتحقق من مصادرها." number="04" action={<span className="count-chip muted-chip">{snapshot.research.length} عناصر تجريبية</span>} />
            <div className="research-panel">
              <div className="research-list">
                {snapshot.research.map((item, index) => (
                  <article className="research-row" key={item.id}>
                    <div className={`research-index index-${index + 1}`}>0{index + 1}</div>
                    <div className="research-copy"><div className="research-title-row"><h3>{item.title}</h3><span className={`priority-tag priority-${item.priority}`}>{item.priorityLabel}</span></div><p>{item.summary}</p><div className="research-meta"><span><Layers3 size={13} /> {item.source}</span><span><Clock3 size={13} /> {item.updated}</span></div></div>
                    <div className={`research-status research-${item.status}`}><span />{item.statusLabel}</div>
                    <button className="research-open" aria-label={`تفاصيل ${item.title}`}><ArrowDownLeft size={16} /></button>
                  </article>
                ))}
              </div>
              <div className="research-footer"><span>عرض تجريبي — المصادر لا تُجلب تلقائياً بعد</span><button onClick={() => setNotice('إضافة بحث ستكون متاحة عند ربط الواجهة بمصدر بيانات.')}>قائمة الانتظار <ArrowDownLeft size={14} /></button></div>
            </div>
          </section>

          <section id="validation" className="section-block section-anchor">
            <SectionHeader eyebrow="بوابات الجودة" title="حالة التحقق" description="فحوصات نموذجية تساعد على مراجعة جاهزية أي فرصة قبل التقدم." number="05" action={<span className="validation-overall"><span className="online-pulse" /> {snapshot.metrics.validationsPassed} من {snapshot.metrics.validationsTotal} اجتازت</span>} />
            <div className="validation-grid">
              <div className="validation-list">
                {snapshot.validations.map((item) => (
                  <article className="validation-row" key={item.id}>
                    <div className={`validation-mark ${item.status}`} aria-hidden="true">{item.status === 'passed' ? <Check size={15} /> : item.status === 'review' ? <Clock3 size={15} /> : <CircleDot size={15} />}</div>
                    <div className="validation-text"><strong>{item.title}</strong><span>{item.detail}</span></div>
                    <div className={`validation-label ${item.status}`}>{item.statusLabel}</div>
                  </article>
                ))}
              </div>
              <aside className="validation-aside">
                <div className="validation-score-ring"><div><strong>{Math.round((snapshot.metrics.validationsPassed / snapshot.metrics.validationsTotal) * 100)}<small>%</small></strong><span>جاهزية العينة</span></div></div>
                <p>هذه النسبة تلخص بيانات العرض فقط. لا تمثل اعتماداً امتثالياً أو قانونياً.</p>
              </aside>
            </div>
          </section>

          <section id="tasks" className="section-block section-anchor">
            <SectionHeader
              eyebrow="إيقاع التنفيذ"
              title="المهام"
              description="قائمة مختصرة لمتابعة العمل بين الأدوار المختلفة."
              number="06"
              action={<span className="count-chip muted-chip">{snapshot.tasks.length} {taskMode === 'saved' ? 'مهام محفوظة' : 'مهام تجريبية'}</span>}
            />
            <div className="tasks-panel">
              {taskMode === 'saved' && (
                <form className="task-create-form" onSubmit={createTask}>
                  <label>
                    <span>المهمة · Task</span>
                    <input value={taskTitle} onChange={(event) => setTaskTitle(event.target.value)} maxLength={160} required placeholder="عنوان المهمة" />
                  </label>
                  <label>
                    <span>المشروع · Project</span>
                    <input value={taskProject} onChange={(event) => setTaskProject(event.target.value)} maxLength={120} placeholder="اختياري" />
                  </label>
                  <label>
                    <span>الأولوية · Priority</span>
                    <select value={taskPriority} onChange={(event) => setTaskPriority(event.target.value as 'high' | 'medium' | 'low')}>
                      <option value="high">عالية · High</option>
                      <option value="medium">متوسطة · Medium</option>
                      <option value="low">منخفضة · Low</option>
                    </select>
                  </label>
                  <label>
                    <span>الاستحقاق · Due</span>
                    <input type="date" value={taskDue} onChange={(event) => setTaskDue(event.target.value)} />
                  </label>
                  <button className="button button-primary" type="submit" disabled={taskSaving}>
                    {taskSaving ? 'جارٍ الحفظ…' : 'إضافة مهمة محفوظة'}
                  </button>
                </form>
              )}
              {taskMode === 'loading' && <p className="task-data-notice" role="status">جارٍ تحميل المهام المحفوظة… · Loading saved tasks…</p>}
              {taskMode === 'error' && <p className="task-data-notice task-data-error" role="alert">تعذر الوصول إلى المهام المحفوظة؛ لم تُستبدل ببيانات تجريبية.</p>}
              <div className="tasks-heading"><span>المهمة</span><span>المسؤول</span><span>الأولوية</span><span>الاستحقاق</span><span>الحالة</span></div>
              {snapshot.tasks.map((task) => {
                const status = taskMode === 'saved' ? task.status : (localState.taskStatus[task.id] ?? task.status);
                return (
                  <div className={`task-row ${status === 'done' ? 'task-done' : ''}`} key={task.id} data-testid={`row-task-${task.id}`}>
                    <div className="task-title-cell"><button className={`task-check ${status === 'done' ? 'checked' : ''}`} onClick={() => setTaskStatus(task.id, status === 'done' ? 'in_progress' : 'done')} aria-label={status === 'done' ? `إعادة فتح ${task.title}` : `إكمال ${task.title}`}><Check size={13} /></button><div><strong>{task.title}</strong><span>{task.project}</span></div></div>
                    <div className="task-owner"><span className={`owner-avatar owner-${task.ownerTone}`}>{task.ownerInitials}</span>{task.owner}</div>
                    <div><span className={`priority-tag priority-${task.priority}`}>{task.priorityLabel}</span></div>
                    <div className="task-due">{task.due}</div>
                    <div><span className={`task-status status-${status}`}><span />{status === 'done' ? (taskMode === 'saved' ? 'مكتملة · Saved' : 'مكتملة محلياً') : status === 'in_progress' ? 'قيد التنفيذ' : 'قيد الانتظار'}</span></div>
                  </div>
                );
              })}
              {taskMode === 'saved' && snapshot.tasks.length === 0 && <p className="task-data-notice">لا توجد مهام محفوظة بعد · No saved tasks yet.</p>}
              <div className="tasks-footer">
                <span><CircleDot size={13} />{taskMode === 'saved' ? 'هذه المهام محفوظة في ملف محلي على الخادم، بعد تسجيل دخول المالك.' : 'بيانات العرض تجريبية؛ التغييرات محلية في هذا المتصفح فقط.'}</span>
                <button onClick={() => setNotice(taskMode === 'saved' ? 'التقارير والأقسام الأخرى ما زالت تجريبية.' : 'فعّل مصادقة المالك لفتح مهام محفوظة على الخادم.')}>عرض كل المهام <ArrowDownLeft size={14} /></button>
              </div>
            </div>
          </section>

          <section id="approvals" className="section-block section-anchor approval-section">
            <SectionHeader eyebrow="الحوكمة والقرار" title="موافقات الرئيس التنفيذي" description="راجع المقترحات التجريبية؛ قرارات هذه الصفحة لا تفوض ولا تنفذ إجراءات حقيقية." number="07" action={<span className="approval-pending">{snapshot.approvals.filter((item) => !localState.approvalDecisions[item.id]).length} بانتظار المراجعة</span>} />
            <div className="human-approval-banner" data-testid="notice-human-approval">
              <div className="approval-banner-icon"><ShieldCheck size={22} /></div>
              <div><strong>الإنسان في دائرة القرار — دائماً</strong><p>أي إجراء مالي أو قانوني أو متعلق بالحسابات أو غير ذلك من الإجراءات الحساسة يتطلب موافقة بشرية صريحة. هذه اللوحة لا تنفّذ معاملات مالية ولا تمنح صلاحيات تنفيذ.</p></div>
              <div className="banner-lock"><ShieldCheck size={18} /><span>مراجعة بشرية إلزامية</span></div>
            </div>
            <div className="approval-list">
              {snapshot.approvals.map((item) => {
                const decision = localState.approvalDecisions[item.id];
                return (
                  <article className={`approval-card ${decision ? 'approval-decided' : ''}`} key={item.id} data-testid={`card-approval-${item.id}`}>
                    <div className={`approval-type-icon type-${item.tone}`}>{item.category === 'استراتيجية' ? <Compass size={18} /> : item.category === 'شراكة' ? <BriefcaseBusiness size={18} /> : <Target size={18} />}</div>
                    <div className="approval-main">
                      <div className="approval-title-line"><span className="approval-category">{item.category}</span><span className="approval-date">{item.submitted}</span></div>
                      <h3>{item.title}</h3><p>{item.rationale}</p>
                      <div className="approval-requester"><span className={`owner-avatar owner-${item.ownerTone}`}>{item.ownerInitials}</span><span>مقترح من <b>{item.owner}</b></span><span className="approval-id">#{item.reference}</span></div>
                    </div>
                    <div className="approval-actions">
                      {decision ? (
                        <div className={`decision-state ${decision}`}><CircleCheck size={16} />{decision === 'approved' ? 'مقبول للعرض فقط' : 'مرفوض للعرض فقط'}</div>
                      ) : (
                        <><button className="button button-approve" onClick={() => decideApproval(item.id, 'approved')}><Check size={15} /> قبول تجريبي</button><button className="button button-decline" onClick={() => decideApproval(item.id, 'rejected')}><X size={15} /> رفض تجريبي</button></>
                      )}
                      <span className="local-only-label">محلي · لا ينفّذ إجراء</span>
                    </div>
                  </article>
                );
              })}
            </div>
            <div className="approval-disclaimer"><AlertTriangle size={14} /> قرارات الموافقة والرفض محفوظة محلياً للعرض فقط، وتُمسح عند إزالة بيانات المتصفح.</div>
          </section>

          <footer className="page-footer">
            <div className="footer-brand"><div className="footer-symbol"><Sparkles size={14} /></div><span>Nova Vision</span></div>
            <span>مركز قيادة تجريبي · إصدار العرض 0.1</span>
            <span className="footer-safe"><ShieldCheck size={14} /> الإنسان يقود القرار</span>
          </footer>
        </div>
      </main>

      {notice && <div className="toast-message" role="status"><CircleCheck size={16} />{notice}<button onClick={() => setNotice('')} aria-label="إغلاق"><X size={14} /></button></div>}
    </div>
  );
}

function MetricCard({ icon: Icon, title, value, foot, color, trend }: { icon: typeof Target; title: string; value: string; foot: string; color: string; trend: string }) {
  return (
    <article className="metric-card" data-testid={`metric-${color}`}>
      <div className={`metric-icon metric-${color}`}><Icon size={18} /></div>
      <span className="metric-trend">{trend}</span>
      <div className="metric-value">{value}</div>
      <div className="metric-title">{title}</div>
      <div className="metric-foot">{foot}</div>
    </article>
  );
}

function SectionHeader({ eyebrow, title, description, number, action }: { eyebrow: string; title: string; description: string; number: string; action?: ReactNode }) {
  return (
    <div className="section-header">
      <div className="section-heading-content"><span className="section-eyebrow"><span>{number}</span>{eyebrow}</span><h2>{title}</h2><p>{description}</p></div>
      {action && <div className="section-header-action">{action}</div>}
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function AppContent() {
  const auth = useOwnerAuth();
  if (auth.loading) {
    return <div className="loading-screen" dir="rtl" lang="ar"><div className="loading-mark"><Sparkles size={21} /></div><p>جارٍ التحقق من جلسة المالك… · Checking owner session…</p></div>;
  }
  if (auth.configured && !auth.authenticated) return <OwnerSignInScreen />;

  return (
    <>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter>
      <Toaster />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <OwnerAuthProvider>
          <AppContent />
        </OwnerAuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;