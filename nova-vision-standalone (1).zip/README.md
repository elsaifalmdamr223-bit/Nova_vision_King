# Nova Vision

Nova Vision is the original Arabic/RTL dashboard from the supplied archive, packaged as a standalone Vite + React + TypeScript application with a small Node.js HTTP API. The original dashboard components and visual files are retained.

## Requirements

- Node.js 20 or newer
- npm 10 or newer

## Run locally

```bash
npm install
npm run dev
```

The Vite frontend defaults to `http://localhost:5000` (the Replit preview port). The API defaults to `http://localhost:3001` and is reached by the browser through the Vite `/api` proxy.

Build and run the production server:

```bash
npm run build
npm start
```

The production server defaults to port `5000` and serves `dist/public` and the API from the same origin. `PORT`, `API_PORT`, `BASE_PATH`, and `NOVA_DATA_DIR` can be set when needed; safe local defaults are provided.

## Owner authentication

The app never creates an owner account or password automatically. Until all three settings below are configured, the dashboard remains explicitly in demo mode and task APIs return an error rather than accepting writes:

- `OWNER_EMAIL`
- `OWNER_PASSWORD_HASH`
- `SESSION_SECRET` (at least 32 characters)

Generate a password hash interactively with `npm run owner:hash`. The password is entered without terminal echo. Copy the resulting hash directly to your deployment's secret manager; never commit it or send it in chat. Set the email and a strong, random session secret in the same secret manager. No credential values belong in this repository.

The API uses a signed, eight-hour, HttpOnly, SameSite=Strict session cookie. In production the cookie is also marked Secure. Sign-out clears the cookie. The server does not contain owner credentials or a user database.
Active session IDs are kept in server memory so sign-out revokes the session immediately; restarting the server ends active sessions and requires the owner to sign in again.

## Data and feature status

- **Dashboard, departments, agent map, opportunities, research, validation, approvals, and reports:** existing presentation data remains illustrative/demo data. Local interaction state remains in this browser's `localStorage`; it is not a shared company record.
- **Tasks:** in demo mode, sample task status changes remain local to the browser. After owner authentication is configured and successful, task creation and status changes use protected `/api/tasks` routes and are saved in `data/tasks.json` on the server. This is file persistence, not PostgreSQL, and is intended for a single running instance. Back up the data file before moving or replacing the project.
- **Reports API:** `/api/reports/summary` derives a small summary from saved tasks. Other dashboard reports remain demo-only.
- **AI agents and external services:** not connected or executed. The app does not call paid services and contains no API keys.
- **Database:** not configured or used by this standalone build. `DATABASE_URL` is not read. No migrations run.

For durable multi-instance hosting, team accounts, department management, audit logs, notifications, and real agent orchestration, a deliberate database and further authorization design will be needed. This package does not claim those capabilities are active.

## Tests

```bash
npm run typecheck
npm test
npm run build
```

The API tests use temporary test-only credentials and temporary data directories; they do not create a real owner or alter an existing database.
